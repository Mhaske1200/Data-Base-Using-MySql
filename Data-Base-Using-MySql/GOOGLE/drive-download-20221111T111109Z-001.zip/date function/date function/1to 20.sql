
****************************************************************************************************

                                 Date and Time functions
								 
******************************************************************************************************
 
 *******************************************Question 1*******************************************
 
1. Write a query to display the first day of the month (in datetime format) three
months before the current month.
Sample current date : 2014-09-03
Expected result : 2014-06-01


mysql> select date_format(date_sub(date_sub(curdate() ,interval 3 month),interval 9 day),'%Y/%m/%d')'date';
+------------+
| date       |
+------------+
| 2022/08/01 |
+------------+
1 row in set (0.00 sec)


*******************************************Question 2*********************************************
2. Write a query to display the last day of the month (in datetime format) three
months before the current month.



mysql> select date_format(last_day(date_sub(curdate() ,interval 3 month)),'%Y/%m/%d')'date';
+------------+
| date       |
+------------+
| 2022/08/31 |
+------------+
1 row in set (0.00 sec)


*******************************************Question 3*********************************************
3. Write a query to get the distinct Mondays from hiredate in emp tables.


mysql> select hiredate
    -> from emp
    -> where dayname(hiredate)='monday';
+------------+
| hiredate   |
+------------+
| 1981-09-28 |
+------------+
1 row in set (0.04 sec)

*******************************************Question 4*********************************************
4. Write a query to get the first day of the current year.

*******************************************Question 5*********************************************
5. Write a query to get the last day of the current year.

*******************************************Question 6*********************************************
6. Write a query to calculate your age in year.


mysql> select floor(datediff(curdate(),'1998-12-11')/365)'age';
+------+
| age  |
+------+
|   23 |
+------+
1 row in set (0.00 sec)

*******************************************Question 7*********************************************
7. Write a query to get the current date in the following format.
Sample date : 04-sep-2014
Output : September 4, 2014

mysql> select date_format(curdate(),'%M  %d, %Y');
+-------------------------------------+
| date_format(curdate(),'%M  %d, %Y') |
+-------------------------------------+
| November  10, 2022                  |
+-------------------------------------+
1 row in set (0.00 sec)


*******************************************Question 8*********************************************
8. Write a query to get the current date in Thursday September 2014 format.
Thursday September 2014


mysql> select date_format(curdate(),'%a  %M, %Y');
+-------------------------------------+
| date_format(curdate(),'%a  %M, %Y') |
+-------------------------------------+
| Thu  November, 2022                 |
+-------------------------------------+
1 row in set (0.00 sec)

*******************************************Question 9*********************************************

9. Write a query to extract the year from the current date.


mysql> select year(curdate())
    -> ;
+-----------------+
| year(curdate()) |
+-----------------+
|            2022 |
+-----------------+
1 row in set (0.00 sec)

*******************************************Question 10*******************************************
10. Write a query to get the first name and hire date from employees table
where hire date between '1987-06-01' and '1987-07-30'


mysql> select ename ,hiredate
    -> from emp
    -> where hiredate between '1987-06-01' and '1987-07-30';
Empty set (0.05 sec)

============== change the dates as we get empty set =============

mysql> select ename ,hiredate
    -> from emp
    -> where hiredate between '1980-06-01' and '1981-07-30';
+-------+------------+
| ename | hiredate   |
+-------+------------+
| SMITH | 1980-12-17 |
| ALLEN | 1981-02-20 |
| WARD  | 1981-02-22 |
| JONES | 1981-04-02 |
| BLAKE | 1981-05-01 |
| CLARK | 1981-06-09 |
+-------+------------+
6 rows in set (0.00 sec)

*******************************************Question 11*********************************************
11. Write a query to display the current date in the following format.
Sample output: Thursday 4th September 2014 00:00:00


mysql> select date_format(now(),'%a %D %M, %Y   %H:%i:%s');
+----------------------------------------------+
| date_format(now(),'%a %D %M, %Y   %H:%i:%s') |
+----------------------------------------------+
| Thu 10th November, 2022   20:42:40           |
+----------------------------------------------+
1 row in set (0.00 sec)

*******************************************Question 12*********************************************
12. Write a query to display the current date in the following format.
Sample output: 05/09/2014


mysql> select date_format(curdate(),' %d/%m/%Y');
+------------------------------------+
| date_format(curdate(),' %d/%m/%Y') |
+------------------------------------+
|  10/11/2022                        |
+------------------------------------+
1 row in set (0.00 sec)

*******************************************Question 13*********************************************
13. Write a query to display the current date in the following format.
Sample output: 12:00 AM Sep 5, 2014

mysql> select date_format(now(),'%H:%i %p %M %d,%Y');
+----------------------------------------+
| date_format(now(),'%H:%i %p %M %d,%Y') |
+----------------------------------------+
| 20:48 PM November 10,2022              |
+----------------------------------------+
1 row in set (0.00 sec)


*******************************************Question 14*********************************************
14. Write a query to get the employees who joined in the month of June.

mysql> select *
    -> from emp
    -> where monthname(hiredate)='june';
+-------+-------+---------+------+------------+---------+------+--------+
| empno | ENAME | JOB     | MGR  | HIREDATE   | SAL     | COMM | DEPTNO |
+-------+-------+---------+------+------------+---------+------+--------+
|  7782 | CLARK | manager | 7777 | 1981-06-09 | 6878.67 | NULL |     10 |
+-------+-------+---------+------+------------+---------+------+--------+
1 row in set (0.00 sec)


*******************************************Question 15*********************************************
15. Write a query to get the years in which more than 10 employees joined.


mysql> select year(hiredate),count(*)
    -> from emp
    -> group by hiredate
    -> having count(*)>10;
Empty set (0.00 sec)

=================changing values as empty set occured==========================================

mysql> select year(hiredate),count(*)
    -> from emp
    -> group by hiredate
    -> having count(*)>1;
+----------------+----------+
| year(hiredate) | count(*) |
+----------------+----------+
|           1981 |        2 |
+----------------+----------+
1 row in set (0.00 sec)



*******************************************Question 16*********************************************
16. Write a query to get first name of employees who joined in 1987.


mysql> select ename
    -> from emp
    -> where year(hiredate)='1987';
Empty set (0.00 sec)
=============change year as it is nt present in table emp=======
mysql> select ename
    -> from emp
    -> where year(hiredate)='1981';
+--------+
| ename  |
+--------+
| ALLEN  |
| WARD   |
| JONES  |
| MARTIN |
| BLAKE  |
| CLARK  |
| KING   |
| TURNER |
| JAMES  |
| FORD   |
+--------+
10 rows in set (0.00 sec)

*******************************************Question 17*********************************************
17. Write a query to get employees whose experience is more than 5 years.


mysql> select *
    -> from emp
    -> where floor(datediff(curdate(),hiredate)/365)>5;
+-------+--------+----------+------+------------+----------+---------+--------+
| empno | ENAME  | JOB      | MGR  | HIREDATE   | SAL      | COMM    | DEPTNO |
+-------+--------+----------+------+------------+----------+---------+--------+
|  7369 | SMITH  | CLERK    | 7902 | 1980-12-17 |  2246.10 |    NULL |     20 |
|  7499 | ALLEN  | SALESMAN | 7698 | 1981-02-20 |  4792.19 |  300.00 |     30 |
|  7521 | WARD   | SALESMAN | 7698 | 1981-02-22 |  4009.52 |  500.00 |     30 |
|  7566 | JONES  | MANAGER  | 7839 | 1981-04-02 |  8352.67 |    NULL |     20 |
|  7654 | MARTIN | SALESMAN | 7698 | 1981-09-28 |  4909.52 | 1400.00 |     30 |
|  7698 | BLAKE  | MANAGER  | 7839 | 1981-05-01 |  8001.71 |    NULL |     30 |
|  7782 | CLARK  | manager  | 7777 | 1981-06-09 |  6878.67 |    NULL |     10 |
|  7788 | SCOTT  | ANALYST  | 7566 | 1982-12-09 |  8422.86 |    NULL |     20 |
|  7839 | KING   | manager  | 7777 | 1981-11-17 | 14038.10 |    NULL |     10 |
|  7844 | TURNER | SALESMAN | 7698 | 1981-09-08 |  4211.43 |    0.00 |     30 |
|  7876 | ADAMS  | CLERK    | 7788 | 1983-01-12 |  3088.38 |    NULL |     20 |
|  7900 | JAMES  | CLERK    | 7698 | 1981-12-03 |  2667.25 |    NULL |     30 |
|  7902 | FORD   | ANALYST  | 7566 | 1981-12-03 |  8422.86 |    NULL |     20 |
|  7934 | MILLER | manager  | 7777 | 1982-01-23 |  3649.90 |    NULL |     10 |
+-------+--------+----------+------+------------+----------+---------+--------+
14 rows in set (0.00 sec)

*******************************************Question 18*********************************************
18. Write a query to get employee ID, last name, and date of first salary of the
employees.

mysql> select empno,ename,hiredate,date_format(date_add(hiredate,interval 1 month),'%Y-%m-%d')"sal date"
    -> from emp;
+-------+--------+------------+------------+
| empno | ename  | hiredate   | sal date   |
+-------+--------+------------+------------+
|  7369 | SMITH  | 1980-12-17 | 1981-01-17 |
|  7499 | ALLEN  | 1981-02-20 | 1981-03-20 |
|  7521 | WARD   | 1981-02-22 | 1981-03-22 |
|  7566 | JONES  | 1981-04-02 | 1981-05-02 |
|  7654 | MARTIN | 1981-09-28 | 1981-10-28 |
|  7698 | BLAKE  | 1981-05-01 | 1981-06-01 |
|  7782 | CLARK  | 1981-06-09 | 1981-07-09 |
|  7788 | SCOTT  | 1982-12-09 | 1983-01-09 |
|  7839 | KING   | 1981-11-17 | 1981-12-17 |
|  7844 | TURNER | 1981-09-08 | 1981-10-08 |
|  7876 | ADAMS  | 1983-01-12 | 1983-02-12 |
|  7900 | JAMES  | 1981-12-03 | 1982-01-03 |
|  7902 | FORD   | 1981-12-03 | 1982-01-03 |
|  7934 | MILLER | 1982-01-23 | 1982-02-23 |
+-------+--------+------------+------------+
14 rows in set (0.00 sec)


*******************************************Question 19*********************************************
19. Write a query to get first name, hire date and experience of the
employees.
Sample table: employees


mysql> select ename,hiredate, floor(datediff(curdate(),hiredate)/365)'exp'
    -> from emp;
+--------+------------+------+
| ename  | hiredate   | exp  |
+--------+------------+------+
| SMITH  | 1980-12-17 |   41 |
| ALLEN  | 1981-02-20 |   41 |
| WARD   | 1981-02-22 |   41 |
| JONES  | 1981-04-02 |   41 |
| MARTIN | 1981-09-28 |   41 |
| BLAKE  | 1981-05-01 |   41 |
| CLARK  | 1981-06-09 |   41 |
| SCOTT  | 1982-12-09 |   39 |
| KING   | 1981-11-17 |   41 |
| TURNER | 1981-09-08 |   41 |
| ADAMS  | 1983-01-12 |   39 |
| JAMES  | 1981-12-03 |   40 |
| FORD   | 1981-12-03 |   40 |
| MILLER | 1982-01-23 |   40 |
+--------+------------+------+
14 rows in set (0.00 sec)

*******************************************Question 20*********************************************
20. Write a query to get the department ID, year, and number of employees
joined.


mysql> select deptno, year(hiredate),count(*)
    -> from emp
    -> group by year(hiredate);
+--------+----------------+----------+
| deptno | year(hiredate) | count(*) |
+--------+----------------+----------+
|     20 |           1980 |        1 |
|     30 |           1981 |       10 |
|     20 |           1982 |        2 |
|     20 |           1983 |        1 |
+--------+----------------+----------+
4 rows in set (0.00 sec)