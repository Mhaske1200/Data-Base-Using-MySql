========================================================================================================================================================

1. Write a MongoDB query to display all the documents in the collection restaurants


db.restaurants.find().pretty()

========================================================================================================================================================

2. Write a MongoDB query to display the fields restaurant_id, name, borough and cuisine for all the documents in the collection restaurant.

 db.restaurants.find({},{_id:1,name:1,borough:1,cuisine:1}).pretty()

========================================================================================================================================================

3. Write a MongoDB query to display the fields restaurant_id, name, borough and cuisine, but exclude the field _id for all the documents in the collection restaurant. 

> db.restaurants.find({},{_id:0,name:1,borough:1,cuisine:1}).pretty()

===================================================================================================================================================================================

4. Write a MongoDB query to display the fields restaurant_id, name, borough and zip code, but exclude the field _id for all the documents in the collection restaurant.

> db.restaurants.find({},{_id:0,name:1,borough:1,"address.zipcode":1}).pretty()

========================================================================================================================================================

5. Write a MongoDB query to display all the restaurant which is in the borough Bronx

 db.restaurants.find({borough:'Bronx'},{name:1,_id:0,borough:1}).pretty()

========================================================================================================================================================


 6. Write a MongoDB query to display the first 5 restaurant which is in the borough Bronx.

  > db.restaurants.find({borough:'Bronx'},{name:1,_id:0,borough:1}).limit(5).pretty()
{ "borough" : "Bronx", "name" : "Morris Park Bake Shop" }
{ "borough" : "Bronx", "name" : "Wild Asia" }
{ "borough" : "Bronx", "name" : "Carvel Ice Cream" }
{ "borough" : "Bronx", "name" : "Happy Garden" }
{ "borough" : "Bronx", "name" : "Happy Garden" }

========================================================================================================================================================

7.Write a MongoDB query to display the next 5 restaurants after skipping first 5 which are in the borough Bronx

> db.restaurants.find({borough:'Bronx'},{name:1,_id:0,borough:1}).limit(5).skip(
5).pretty()
{ "borough" : "Bronx", "name" : "Manhem Club" }
{
        "borough" : "Bronx",
        "name" : "The New Starling Athletic Club Of The Bronx"
}
{ "borough" : "Bronx", "name" : "Yankee Tavern" }
{ "borough" : "Bronx", "name" : "Mcdwyers Pub" }
{ "borough" : "Bronx", "name" : "The Punch Bowl" }
>

========================================================================================================================================================
8. Write a MongoDB query to find the restaurants who achieved a score more than 90.

> db.restaurants.find({"grades.score":{$gt:90}},{name:1,_id:0})
{ "name" : "Murals On 54/Randolphs'S" }
{ "name" : "Gandhi" }
{ "name" : "Bella Napoli" }
{ "name" : "Baluchi'S Indian Food" }

========================================================================================================================================================
9. Write a MongoDB query to find the restaurants that achieved a score, more than 80 but less than 100.

> db.restaurants.find({"grades.score":{$gt:80,$lt:100}},{name:1,_id:0}).pretty()

{ "name" : "Murals On 54/Randolphs'S" }
{ "name" : "Gandhi" }
{ "name" : "Bella Napoli" }
{ "name" : "West 79Th Street Boat Basin Cafe" }
{ "name" : "Spicy Shallot" }
{ "name" : "Bistro Caterers" }
{ "name" : "Concrete Restaurant" }
{ "name" : "Anella" }
{ "name" : "Baluchi'S Indian Food" }
{ "name" : "Cafe R" }
{ "name" : "D & Y Restaurant" }
{ "name" : "La Potencia Restaurant" }

======================================================================================================================================================

10. Write a MongoDB query to find the restaurants which locate in latitude value less than -95.754168.

> db.restaurants.find({"address.coord.0":{$lt:95.754168}},{name:1,_id:0}).pretty
()
{ "name" : "Wendy'S" }
{ "name" : "Morris Park Bake Shop" }
{ "name" : "Tov Kosher Kitchen" }
{ "name" : "Brunos On The Boulevard" }
{ "name" : "Kosher Island" }
{ "name" : "Dj Reynolds Pub And Restaurant" }
{ "name" : "Riviera Caterer" }
{ "name" : "Regina Caterers" }
{ "name" : "Taste The Tropics Ice Cream" }
{ "name" : "C & C Catering Service" }
{ "name" : "May May Kitchen" }
{ "name" : "1 East 66Th Street Kitchen" }
{ "name" : "Seuda Foods" }
{ "name" : "Carvel Ice Cream" }
{ "name" : "Carvel Ice Cream" }
{ "name" : "Wilken'S Fine Food" }
{ "name" : "Wild Asia" }
{ "name" : "Nordic Delicacies" }
{ "name" : "Sal'S Deli" }
{ "name" : "The Movable Feast" }
Type "it" for more

=======================================================================================================================================================

11. Write a MongoDB query to find the restaurants that do not prepare any cuisine of 'American' and their grade score more than 70 and latitude less than -65.754168.


 db.restaurants.find({cuisine:{$nin:['American']},"grades.score":{$gt:70},"address.coord.1":{$lt:65.754168}},{name:1,_id:0}).pretty()
{ "name" : "Gandhi" }
{ "name" : "Bella Napoli" }
{ "name" : "El Molino Rojo Restaurant" }
{ "name" : "Fortunato Bros Cafe & Bakery" }
{ "name" : "Two Boots Grand Central" }
{ "name" : "Spicy Shallot" }
{ "name" : "Midtown Buffet" }
{ "name" : "Pino'S La Forchetta" }
{ "name" : "Los Pollitos Iii" }
{ "name" : "East Japanese Restaurant" }
{ "name" : "Los Mismo Restaurant" }
{ "name" : "Brothers Fish Market" }
{ "name" : "Anella" }
{ "name" : "Ming Wong Restaurant" }
{ "name" : "Baluchi'S Indian Food" }
{ "name" : "La Trattoria" }
{ "name" : "Gal Bi Ma Eul" }
{ "name" : "Wonton Noodle Garden" }
{ "name" : "Cheikh Umar Futiyu Restaurant" }
{ "name" : "Takesushi" }
Type "it" for more

========================================================================================================================================================

12. Write a MongoDB query to find the restaurants which do not prepare any cuisine of 'American' and achieved a score more than 70 and located in 
the longitude less than -65.754168.

db.restaurants.find({cuisine:{$nin:['American']},"grades.score":{$gt:70},"address.coord.0":{$lt:65.754168}},{name:1,_id:0}).pretty()


========================================================================================================================================================

13. Write a MongoDB query to find the restaurants which do not prepare any cuisine of 'American ' and achieved a grade point 'A' not belongs to the borough Brooklyn. 
The document must be displayed according to the cuisine in descending order.

cuisine:{$nin:['American']}
"grades.grade":{$in:['A']}
borough:{$nin:['Brooklyn']}

> db.restaurants.find({cuisine:{$nin:['American']},"grades.grade":{$in:['A']},borough:{$nin:['Brooklyn']}},{name:1,_id:0,borough:1}).sort({cuisine:1}).pretty()
{ "borough" : "Manhattan", "name" : "Afghan Kebab House" }
{ "borough" : "Manhattan", "name" : "Khyber Pass" }
{ "borough" : "Manhattan", "name" : "Afghan Kebab House #1" }
{ "borough" : "Manhattan", "name" : "Ariana Kebab House" }
{ "borough" : "Queens", "name" : "Afghan Kebob House" }
{ "borough" : "Queens", "name" : "Bakhter Afghan Halal Kabab" }
{ "borough" : "Queens", "name" : "Choopan Kabab Restaurant" }
{ "borough" : "Queens", "name" : "Bakhtar Kabab" }
{
        "borough" : "Queens",
        "name" : "New Bkhatar Afghan Halal Kabab & Gyro King"
}
{ "borough" : "Queens", "name" : "Balkh Shish Kabab House" }
{ "borough" : "Queens", "name" : "Arya Kabob House" }
{ "borough" : "Queens", "name" : "Tariq Afghan Kabab" }
{ "borough" : "Queens", "name" : "Bakhter Afghan Halal Kabab" }
{ "borough" : "Bronx", "name" : "African Terrace" }
{ "borough" : "Queens", "name" : "Africana Restaurant" }
{ "borough" : "Bronx", "name" : "Ebe Ye Yie African Restaurant" }
{ "borough" : "Bronx", "name" : "African Maquis La Plantation" }
{ "borough" : "Bronx", "name" : "Halal Coffee Shop Restaurant" }
{ "borough" : "Bronx", "name" : "Jalloh Family Restaurant" }
{ "borough" : "Bronx", "name" : "Webster Halal Food" }
Type "it" for more

========================================================================================================================================================
14. Write a MongoDB query to find the restaurant Id, name, borough and cuisine for those restaurants which contain 'Wil' as first three letters for its name.

db.restaurants.find({name:/^Wil/},{_id:0,restaurant_id:1,name:1,borough:1,cuisine:1}).pretty()




========================================================================================================================================================
15. Write a MongoDB query to find the restaurant Id, name, borough and cuisine for those restaurants which contain 'ces' as last three letters for its name.


db.restaurants.find({name:/ces$/},{_id:0,restaurant_id:1,name:1,borough:1,cuisine:1}).pretty()


========================================================================================================================================================
16. Write a MongoDB query to find the restaurant Id, name, borough and cuisine for those restaurants which contain 'Reg' as three letters somewhere in its name.

db.restaurants.find({name:/.*reg.*/},{_id:0,restaurant_id:1,name:1,borough:1,cuisine:1}).pretty()


========================================================================================================================================================

17. Write a MongoDB query to find the restaurants which belong to the borough Bronx and prepared either American or Chinese dish.








========================================================================================================================================================