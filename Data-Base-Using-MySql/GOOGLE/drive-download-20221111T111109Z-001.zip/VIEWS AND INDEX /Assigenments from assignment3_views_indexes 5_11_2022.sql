======================================================= assignment3_views_indexes =======================================================
1. create all given tables

======================================================= Creating table vehicle =======================================================
mysql> create table vehicle(
    -> vid int primary key,
    -> vname varchar(20),
    -> price double(9,2)check(price>0),
    -> des varchar(30)
    -> );
Query OK, 0 rows affected, 1 warning (0.11 sec)


======================================================= Creating table salesman =======================================================
mysql> create table salesman(
    -> sid int primary key,
    -> sname varchar(20),
    -> address varchar(30)
    -> );
Query OK, 0 rows affected (0.09 sec)

mysql> desc customer;
+---------+-------------+------+-----+---------+-------+
| Field   | Type        | Null | Key | Default | Extra |
+---------+-------------+------+-----+---------+-------+
| custid  | int         | NO   | PRI | NULL    |       |
| cname   | varchar(20) | YES  |     | NULL    |       |
| address | varchar(30) | YES  |     | NULL    |       |
+---------+-------------+------+-----+---------+-------+
3 rows in set (0.00 sec)

======================================================= Creating table cust_vehicle =======================================================

mysql> create table cust_vehicle(
    -> custid int,
    -> vid int,
    -> sid int,
    -> buy_price double(9,2),
    -> constraint pk_1 primary key(custid,vid),
    -> constraint fk_1 foreign key(custid) references customer(custid),
    -> constraint fk_2 foreign key(vid) references vehicle(vid)
    -> );
Query OK, 0 rows affected, 1 warning (0.36 sec)

mysql> desc cust_vehicle;
+-----------+-------------+------+-----+---------+-------+
| Field     | Type        | Null | Key | Default | Extra |
+-----------+-------------+------+-----+---------+-------+
| custid    | int         | NO   | PRI | NULL    |       |
| vid       | int         | NO   | PRI | NULL    |       |
| sid       | int         | YES  |     | NULL    |       |
| buy_price | double(9,2) | YES  |     | NULL    |       |
+-----------+-------------+------+-----+---------+-------+
4 rows in set (0.00 sec)

======================================================= Inserting values in table vehicle ======================================================

mysql> insert into vehicle(vid,vname,price,des)values(1,'Activa',80000,'No mileage');
Query OK, 1 row affected (0.04 sec)

mysql> insert into vehicle(vid,vname,price,des)values
    -> (2,'Santro',800000,'Good family car'),
    -> (3,'Motor bike',100000,'No motor available');
Query OK, 2 rows affected (0.04 sec)
Records: 2  Duplicates: 0  Warnings: 0

mysql> select *  from vehicle;
+-----+------------+-----------+--------------------+
| vid | vname      | price     | des                |
+-----+------------+-----------+--------------------+
|   1 | Activa     |  80000.00 | No mileage         |
|   2 | Santro     | 800000.00 | Good family car    |
|   3 | Motor bike | 100000.00 | No motor available |
+-----+------------+-----------+--------------------+
3 rows in set (0.00 sec)

======================================================= Inserting values in table customer ======================================================


mysql> insert into customer(custid,cname,address)values
    -> (1,'Nilima','Pimpri'),
    -> (2,'Ganesh','Pune'),
    -> (3,'Pankaj','Mumbai');
Query OK, 3 rows affected (0.04 sec)
Records: 3  Duplicates: 0  Warnings: 0

mysql> select * from customer;
+--------+--------+---------+
| custid | cname  | address |
+--------+--------+---------+
|      1 | Nilima | Pimpri  |
|      2 | Ganesh | Pune    |
|      3 | Pankaj | Mumbai  |
+--------+--------+---------+
3 rows in set (0.00 sec)

======================================================= Inserting values in table salesman ======================================================

mysql> insert into salesman(sid,sname,address)values
    -> (10,'Rajesh','Mumbai'),
    -> (11,'Seema','Pune'),
    -> (13,'Rakhi','Pune');
Query OK, 3 rows affected (0.03 sec)
Records: 3  Duplicates: 0  Warnings: 0

mysql> select * from salesman;
+-----+--------+---------+
| sid | sname  | address |
+-----+--------+---------+
|  10 | Rajesh | Mumbai  |
|  11 | Seema  | Pune    |
|  13 | Rakhi  | Pune    |
+-----+--------+---------+
3 rows in set (0.00 sec)

======================================================= Inserting values in table cust_vehicle ======================================================

mysql> insert into cust_vehicle(custid,vid,sid,buy_price)values
    -> (1,1,10,75000),
    -> (1,2,10,790000),
    -> (2,3,11,80000),
    -> (3,3,11,75000),
    -> (3,2,10,800000);
Query OK, 5 rows affected (0.04 sec)
Records: 5  Duplicates: 0  Warnings: 0


======================================================= Creating index on vehicle =======================================================

2. create index on vehicle table based on price

mysql> create index pr_index
    -> on vehicle(price);
Query OK, 0 rows affected (0.30 sec)
Records: 0  Duplicates: 0  Warnings: 0

mysql> show index from vehicle;
+---------+------------+----------+--------------+-------------+-----------+-------------+----------+--------+------+------------+---------+---------------+----
-----+------------+
| Table   | Non_unique | Key_name | Seq_in_index | Column_name | Collation | Cardinality | Sub_part | Packed | Null | Index_type | Comment | Index_comment | Vis
ible | Expression |
+---------+------------+----------+--------------+-------------+-----------+-------------+----------+--------+------+------------+---------+---------------+----
-----+------------+
| vehicle |          0 | PRIMARY  |            1 | vid         | A         |           3 |     NULL |   NULL |      | BTREE      |         |               | YES
     | NULL       |
| vehicle |          1 | pr_index |            1 | price       | A         |           3 |     NULL |   NULL | YES  | BTREE      |         |               | YES
     | NULL       |
+---------+------------+----------+--------------+-------------+-----------+-------------+----------+--------+------+------------+---------+---------------+----
-----+------------+
2 rows in set (0.00 sec)

======================================================= Question 3 =======================================================


3. find all customer name,vehicle name, salesman name, discount earn by all customer


mysql> select c.cname,v.vname,s.sname,(v.price-cv.buy_price)'Discount earn by customer'
    -> from customer c,vehicle v,salesman s,cust_vehicle cv
    -> where cv.custid=c.custid and s.sid=cv.sid and v.vid=cv.vid;
+--------+------------+--------+---------------------------+
| cname  | vname      | sname  | Discount earn by customer |
+--------+------------+--------+---------------------------+
| Nilima | Activa     | Rajesh |                   5000.00 |
| Nilima | Santro     | Rajesh |                  10000.00 |
| Ganesh | Motor bike | Seema  |                  20000.00 |
| Pankaj | Santro     | Rajesh |                      0.00 |
| Pankaj | Motor bike | Seema  |                  25000.00 |
+--------+------------+--------+---------------------------+
5 rows in set (0.00 sec)

======================================================= Question 4 =======================================================

4. find all customer name,vehicle name,salesman name for all salesman who stays in pune

mysql> select c.cname,v.vname,s.sname
    -> from customer c,vehicle v,salesman s,cust_vehicle cv
    -> where cv.custid=c.custid and s.sid=cv.sid and v.vid=cv.vid and s.address='pune';
+--------+------------+-------+
| cname  | vname      | sname |
+--------+------------+-------+
| Ganesh | Motor bike | Seema |
| Pankaj | Motor bike | Seema |
+--------+------------+-------+
2 rows in set (0.00 sec)

======================================================= Question 5 =======================================================

5. find how many customers bought motor bike

mysql> select v.vname,count(*)
    -> from customer c,cust_vehicle cv,vehicle v
    -> where c.custid=cv.custid and v.vid=cv.vid and v.vname='motor bike'
    -> ;
+------------+----------+
| vname      | count(*) |
+------------+----------+
| Motor bike |        2 |
+------------+----------+
1 row in set (0.00 sec)


======================================================= Question 6 =======================================================

6. create a view find_discount which displays output 
-------to create view
 create view find_discount
 as 
 select cname,vname,price,buying_price,price-buying_price “discount”
 from customer c inner join cust_vehicle cv on c.custid=cv.cid inner join vehicle v on 
 v.vid=cv.vid
 --------to display discount 
 select * from find_discount;

======================================================= By using inner join =======================================================

mysql> create view find_discount
    -> as
    -> select c.cname,v.vname,v.price,cv.buy_price,v.price-cv.buy_price"Discount"
    -> from customer c inner join cust_vehicle cv
    -> on c.custid=cv.custid inner join vehicle v on v.vid=cv.vid;
Query OK, 0 rows affected (0.06 sec)

mysql> select * from find_discount;
+--------+------------+-----------+-----------+----------+
| cname  | vname      | price     | buy_price | Discount |
+--------+------------+-----------+-----------+----------+
| Nilima | Activa     |  80000.00 |  75000.00 |  5000.00 |
| Nilima | Santro     | 800000.00 | 790000.00 | 10000.00 |
| Ganesh | Motor bike | 100000.00 |  80000.00 | 20000.00 |
| Pankaj | Santro     | 800000.00 | 800000.00 |     0.00 |
| Pankaj | Motor bike | 100000.00 |  75000.00 | 25000.00 |
+--------+------------+-----------+-----------+----------+
5 rows in set (0.00 sec)

======================================================= By using where =======================================================

mysql> select c.cname,v.vname,v.price,cv.buy_price,v.price-cv.buy_price"Discount"
    -> from customer c ,cust_vehicle cv,vehicle v
    -> where c.custid=cv.custid and v.vid=cv.vid;
+--------+------------+-----------+-----------+----------+
| cname  | vname      | price     | buy_price | Discount |
+--------+------------+-----------+-----------+----------+
| Nilima | Activa     |  80000.00 |  75000.00 |  5000.00 |
| Nilima | Santro     | 800000.00 | 790000.00 | 10000.00 |
| Ganesh | Motor bike | 100000.00 |  80000.00 | 20000.00 |
| Pankaj | Santro     | 800000.00 | 800000.00 |     0.00 |
| Pankaj | Motor bike | 100000.00 |  75000.00 | 25000.00 |
+--------+------------+-----------+-----------+----------+
5 rows in set (0.00 sec)

======================================================= Question 7 =======================================================

7. find all customer name, vehicle name, salesman name, discount earn by all customer



======================================================= Question 8 =======================================================

8. create view my_hr to display empno,ename,job,comm for all employees who earn 
commission

mysql> create view my_hr
    -> as
    -> select empno,ename,job,comm
    -> from emp
    -> where comm is not null and comm!=0;
Query OK, 0 rows affected (0.03 sec)

mysql> select * from my_hr;
+-------+--------+----------+---------+
| empno | ename  | job      | comm    |
+-------+--------+----------+---------+
|  7499 | ALLEN  | SALESMAN |  300.00 |
|  7521 | WARD   | SALESMAN |  500.00 |
|  7654 | MARTIN | SALESMAN | 1400.00 |
+-------+--------+----------+---------+
3 rows in set (0.02 sec)

======================================================= Question 9 =======================================================

9. create view mgr30 to display all employees from department 30

mysql> create view mgr30
    -> as
    -> select *
    -> from emp
    -> where deptno=30;
Query OK, 0 rows affected (0.06 sec)

mysql> select * from mgr30;
+-------+--------+----------+------+------------+---------+---------+--------+
| empno | ENAME  | JOB      | MGR  | HIREDATE   | SAL     | COMM    | DEPTNO |
+-------+--------+----------+------+------------+---------+---------+--------+
|  7499 | ALLEN  | SALESMAN | 7698 | 1981-02-20 | 1600.00 |  300.00 |     30 |
|  7521 | WARD   | SALESMAN | 7698 | 1981-02-22 | 1250.00 |  500.00 |     30 |
|  7654 | MARTIN | SALESMAN | 7698 | 1981-09-28 | 1250.00 | 1400.00 |     30 |
|  7698 | BLAKE  | MANAGER  | 7839 | 1981-05-01 | 2850.00 |    NULL |     30 |
|  7844 | TURNER | SALESMAN | 7698 | 1981-09-08 | 1500.00 |    0.00 |     30 |
|  7900 | JAMES  | CLERK    | 7698 | 1981-12-03 |  950.00 |    NULL |     30 |
+-------+--------+----------+------+------------+---------+---------+--------+
6 rows in set (0.00 sec)

======================================================= Question 10 =======================================================

10. insert 3 employees in view mgr30 check whether insertion is possible

======================================================= Solution =======================================================

As per abhishek verma sir's saying records cannot be inserted as empno is primary key.



======================================================= Question 10 =======================================================

14. create a procedure getMin(deptno,minsal) to find minimum salary of given table.
mysql> delimiter //

mysql> create procedure getMin(ddeptno int,out minsal int)
    -> begin
    -> select min(sal) into minsal
    -> from emp
    -> where deptno=ddeptno;
    -> end//
Query OK, 0 rows affected (0.08 sec)

mysql> call getmin(10,@c);
    -> //
Query OK, 1 row affected (0.07 sec)

mysql> select @c //
+------+
| @c   |
+------+
| 1300 |
+------+
1 row in set (0.00 sec)

mysql> delimiter ;