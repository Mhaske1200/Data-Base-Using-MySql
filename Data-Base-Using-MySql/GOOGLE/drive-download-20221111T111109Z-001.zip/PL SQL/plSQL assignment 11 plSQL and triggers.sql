================================================= Question 1 ===============================================================

1. write a procedure to insert record into employee table.
the procedure should accept empno, ename, sal, job, hiredate as input parameter
write insert statement inside procedure insert_rec to add one record into table
create procedure insert_rec(peno int,pnm varchar(20),psal decimal(9,2),pjob 
varchar(20),phiredate date)
begin
 insert into emp(empno,ename,sal,job,hiredate) 
values(peno,pnm,psal,pjob,phiredate)
end//

================================================== Creating procedure =================================================
mysql> delimiter //
mysql> create procedure insert_records(pempno int,pename varchar(20),psal decimal(9,2),pjob varchar(20),phiredate date)
    -> begin
    -> insert into emp(empno,ename,sal,job,hiredate)
    -> values(pempno,pename,psal,pjob,phiredate);
    -> end //
Query OK, 0 rows affected (0.13 sec)

================================================== Calling procedure =================================================
mysql> call insert_records(101,'Ename1',1000,'CEO','2022-11-07');
    -> //
Query OK, 1 row affected (0.08 sec)

mysql>
mysql>
mysql> select * from emp;
    -> //
+-------+--------+-----------+------+------------+---------+---------+--------+
| empno | ENAME  | JOB       | MGR  | HIREDATE   | SAL     | COMM    | DEPTNO |
+-------+--------+-----------+------+------------+---------+---------+--------+
|   101 | Ename1 | CEO       | NULL | 2022-11-07 | 1000.00 |    NULL |   NULL |
|  7369 | SMITH  | CLERK     | 7902 | 1980-12-17 |  800.00 |    NULL |     20 |
|  7499 | ALLEN  | SALESMAN  | 7698 | 1981-02-20 | 1600.00 |  300.00 |     30 |
|  7521 | WARD   | SALESMAN  | 7698 | 1981-02-22 | 1250.00 |  500.00 |     30 |
|  7566 | JONES  | MANAGER   | 7839 | 1981-04-02 | 2975.00 |    NULL |     20 |
|  7654 | MARTIN | SALESMAN  | 7698 | 1981-09-28 | 1250.00 | 1400.00 |     30 |
|  7698 | BLAKE  | MANAGER   | 7839 | 1981-05-01 | 2850.00 |    NULL |     30 |
|  7700 | test1  | CEO       | 7171 | 2022-11-05 | 1000.00 |  100.00 |     30 |
|  7782 | CLARK  | MANAGER   | 7839 | 1981-06-09 | 2450.00 |    NULL |     10 |
|  7788 | SCOTT  | ANALYST   | 7566 | 1982-12-09 | 3000.00 |    NULL |     20 |
|  7839 | KING   | PRESIDENT | NULL | 1981-11-17 | 5000.00 |    NULL |     10 |
|  7844 | TURNER | SALESMAN  | 7698 | 1981-09-08 | 1500.00 |    0.00 |     30 |
|  7876 | ADAMS  | CLERK     | 7788 | 1983-01-12 | 1100.00 |    NULL |     20 |
|  7900 | JAMES  | CLERK     | 7698 | 1981-12-03 |  950.00 |    NULL |     30 |
|  7902 | FORD   | ANALYST   | 7566 | 1981-12-03 | 3000.00 |    NULL |     20 |
|  7934 | MILLER | CLERK     | 7782 | 1982-01-23 | 1300.00 |    NULL |     10 |
+-------+--------+-----------+------+------------+---------+---------+--------+
16 rows in set (0.00 sec)

================================================= Question 2 ===============================================================

2. write a procedure to delete record from employee table.
the procedure should accept empno as input parameter.
write delete statement inside procedure delete_emp to delete one record from emp 
table


mysql> create procedure delete_records(pempno int)
    -> begin
    -> delete from emp
    -> where empno=pempno;
    -> end //
Query OK, 0 rows affected (0.04 sec)

================================================= Calling created procedure ============================================

mysql> call delete_records(101);
    -> //
Query OK, 1 row affected (0.00 sec)

================================================= Table before deleting record 101 ======================================

+-------+--------+-----------+------+------------+---------+---------+--------+
| empno | ENAME  | JOB       | MGR  | HIREDATE   | SAL     | COMM    | DEPTNO |
+-------+--------+-----------+------+------------+---------+---------+--------+
|   101 | Ename1 | CEO       | NULL | 2022-11-07 | 1000.00 |    NULL |   NULL |
|  7369 | SMITH  | CLERK     | 7902 | 1980-12-17 |  800.00 |    NULL |     20 |
|  7499 | ALLEN  | SALESMAN  | 7698 | 1981-02-20 | 1600.00 |  300.00 |     30 |
|  7521 | WARD   | SALESMAN  | 7698 | 1981-02-22 | 1250.00 |  500.00 |     30 |
|  7566 | JONES  | MANAGER   | 7839 | 1981-04-02 | 2975.00 |    NULL |     20 |
|  7654 | MARTIN | SALESMAN  | 7698 | 1981-09-28 | 1250.00 | 1400.00 |     30 |
|  7698 | BLAKE  | MANAGER   | 7839 | 1981-05-01 | 2850.00 |    NULL |     30 |
|  7700 | test1  | CEO       | 7171 | 2022-11-05 | 1000.00 |  100.00 |     30 |
|  7782 | CLARK  | MANAGER   | 7839 | 1981-06-09 | 2450.00 |    NULL |     10 |
|  7788 | SCOTT  | ANALYST   | 7566 | 1982-12-09 | 3000.00 |    NULL |     20 |
|  7839 | KING   | PRESIDENT | NULL | 1981-11-17 | 5000.00 |    NULL |     10 |
|  7844 | TURNER | SALESMAN  | 7698 | 1981-09-08 | 1500.00 |    0.00 |     30 |
|  7876 | ADAMS  | CLERK     | 7788 | 1983-01-12 | 1100.00 |    NULL |     20 |
|  7900 | JAMES  | CLERK     | 7698 | 1981-12-03 |  950.00 |    NULL |     30 |
|  7902 | FORD   | ANALYST   | 7566 | 1981-12-03 | 3000.00 |    NULL |     20 |
|  7934 | MILLER | CLERK     | 7782 | 1982-01-23 | 1300.00 |    NULL |     10 |
+-------+--------+-----------+------+------------+---------+---------+--------+




================================================= Table After deleting record 101 ======================================

mysql> select * from emp;
    -> //
+-------+--------+-----------+------+------------+---------+---------+--------+
| empno | ENAME  | JOB       | MGR  | HIREDATE   | SAL     | COMM    | DEPTNO |
+-------+--------+-----------+------+------------+---------+---------+--------+
|  7369 | SMITH  | CLERK     | 7902 | 1980-12-17 |  800.00 |    NULL |     20 |
|  7499 | ALLEN  | SALESMAN  | 7698 | 1981-02-20 | 1600.00 |  300.00 |     30 |
|  7521 | WARD   | SALESMAN  | 7698 | 1981-02-22 | 1250.00 |  500.00 |     30 |
|  7566 | JONES  | MANAGER   | 7839 | 1981-04-02 | 2975.00 |    NULL |     20 |
|  7654 | MARTIN | SALESMAN  | 7698 | 1981-09-28 | 1250.00 | 1400.00 |     30 |
|  7698 | BLAKE  | MANAGER   | 7839 | 1981-05-01 | 2850.00 |    NULL |     30 |
|  7700 | test1  | CEO       | 7171 | 2022-11-05 | 1000.00 |  100.00 |     30 |
|  7782 | CLARK  | MANAGER   | 7839 | 1981-06-09 | 2450.00 |    NULL |     10 |
|  7788 | SCOTT  | ANALYST   | 7566 | 1982-12-09 | 3000.00 |    NULL |     20 |
|  7839 | KING   | PRESIDENT | NULL | 1981-11-17 | 5000.00 |    NULL |     10 |
|  7844 | TURNER | SALESMAN  | 7698 | 1981-09-08 | 1500.00 |    0.00 |     30 |
|  7876 | ADAMS  | CLERK     | 7788 | 1983-01-12 | 1100.00 |    NULL |     20 |
|  7900 | JAMES  | CLERK     | 7698 | 1981-12-03 |  950.00 |    NULL |     30 |
|  7902 | FORD   | ANALYST   | 7566 | 1981-12-03 | 3000.00 |    NULL |     20 |
|  7934 | MILLER | CLERK     | 7782 | 1982-01-23 | 1300.00 |    NULL |     10 |
+-------+--------+-----------+------+------------+---------+---------+--------+
15 rows in set (0.00 sec)


================================================= Question 3 =================================================

3. write a procedure to display empno,ename,deptno,dname for all employees with sal 
> given salary. pass salary as a parameter to procedure

mysql> create procedure getsalgreater(psal decimal)
    -> begin
    -> select e.empno,e.ename,d.deptno,d.dname
    -> from emp e,dept d
    -> where e.deptno = d.deptno and e.sal > psal;
    -> end //
Query OK, 0 rows affected (0.06 sec)

======================Checking records for salary greater than 3000 so result we atr getting is only KING because there ======================is only one person who got salary greater than 3000 =================================================

mysql> call getsalgreater(3000)
    -> //
+-------+-------+--------+------------+
| empno | ename | deptno | dname      |
+-------+-------+--------+------------+
|  7839 | KING  |     10 | ACCOUNTING |
+-------+-------+--------+------------+
1 row in set (0.00 sec)

Query OK, 0 rows affected (0.01 sec)


================================================= Question 4 =================================================

4. write a procedure to find min,max,avg of salary and number of employees in the 
given deptno.
deptno --→ in parameter 
min,max,avg and count ---→ out type parameter
execute procedure and then display values min,max,avg and count

mysql> create procedure min_max_avg_sal(pdeptno int,out pmin int, out pmax int, out pavg int, out pcount int)
    -> select min(sal),max(sal),avg(sal),count(*) into pmin,pmax,pavg,pcount
    -> from emp e
    -> where deptno=pdeptno;
    -> end //
Query OK, 0 rows affected (0.04 sec)

ERROR 1064 (42000): You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'end' at line 1


mysql> call min_max_avg_sal(10,@a,@b,@c,@d)//
Query OK, 1 row affected (0.00 sec)


================================================= printing data =================================================
mysql> select @a,@b,@c,@d//
+------+------+------+------+
| @a   | @b   | @c   | @d   |
+------+------+------+------+
| 1300 | 5000 | 2917 |    3 |
+------+------+------+------+
1 row in set (0.00 sec)


================================================= Question 5 =================================================

5. write a procedure to display all pid,pname,cid,cname and salesman name(use 
product,category and salesman table)

================================================= Question 6 =================================================

6. write a procedure to display all vehicles bought by a customer. pass cutome name as 
a parameter.(use vehicle,salesman,custome and relation table)

mysql> create procedure displayvehicle(pname varchar(20))
    -> begin
    -> select c.custid,c.cname,v.vname
    -> from customer c,vehicle v,cust_vehicle cv
    -> where cv.custid=c.custid and cv.vid=v.vid and c.cname=pname;
    -> end//
Query OK, 0 rows affected (0.04 sec)

mysql> call displayvehicle('nilima')//
+--------+--------+--------+
| custid | cname  | vname  |
+--------+--------+--------+
|      1 | Nilima | Activa |
|      1 | Nilima | Santro |
+--------+--------+--------+
2 rows in set (0.00 sec)

Query OK, 0 rows affected (0.01 sec)


================================================= Question 7 =================================================

7. Write a procedure that displays the following information of all emp
Empno,Name,job,Salary,Status,deptno
Note: - Status will be (Greater, Lesser or Equal) respective to average salary of their own
department. Display an error message Emp table is empty if there is no matching
record.


mysql> create procedure displayallemp()
    -> begin
    -> declare vstatus varchar(20);
    -> declare vset int default 0;
    -> declare vempno int;
    -> declare vdeptno int;
    -> declare vavg decimal(9,2);
    -> declare vename varchar(30);
    -> declare vsal decimal(9,2);
    -> declare empcur cursor for select empno,ename,sal,deptno from emp;
    -> declare continue handler for not found set vset=1;
    -> open empcur;
    -> label1 :loop
    -> fetch empcur into vempno,vename,vsal,vdeptno;
    -> if vset=1 then
    -> leave label1;
    -> end if ;
    ->  select avg(sal) into vavg
    ->  from emp
    ->  where deptno=vdeptno;
    -> if vsal > vavg then
    ->  set vstatus= 'greater';
    -> elseif  vsal < vavg then
    -> set vstatus ='lesser';
    -> elseif vsal=vavg then
    -> set vstatus='equal';
    -> else
    -> set vstatus =' NO_record';
    -> end if;
    ->  select vempno,vename,vsal,vdeptno,vstatus;
    -> end loop;
    -> close empcur;
    -> end//
Query OK, 0 rows affected (0.10 sec)

mysql>
mysql> call displayallemp//
+--------+--------+--------+---------+---------+
| vempno | vename | vsal   | vdeptno | vstatus |
+--------+--------+--------+---------+---------+
|   7369 | SMITH  | 800.00 |      20 | lesser  |
+--------+--------+--------+---------+---------+
1 row in set (0.01 sec)

+--------+--------+---------+---------+---------+
| vempno | vename | vsal    | vdeptno | vstatus |
+--------+--------+---------+---------+---------+
|   7499 | ALLEN  | 1600.00 |      30 | greater |
+--------+--------+---------+---------+---------+
1 row in set (0.02 sec)

+--------+--------+---------+---------+---------+
| vempno | vename | vsal    | vdeptno | vstatus |
+--------+--------+---------+---------+---------+
|   7521 | WARD   | 1250.00 |      30 | lesser  |
+--------+--------+---------+---------+---------+
1 row in set (0.04 sec)

+--------+--------+---------+---------+---------+
| vempno | vename | vsal    | vdeptno | vstatus |
+--------+--------+---------+---------+---------+
|   7566 | JONES  | 2975.00 |      20 | greater |
+--------+--------+---------+---------+---------+
1 row in set (0.04 sec)

+--------+--------+---------+---------+---------+
| vempno | vename | vsal    | vdeptno | vstatus |
+--------+--------+---------+---------+---------+
|   7654 | MARTIN | 1250.00 |      30 | lesser  |
+--------+--------+---------+---------+---------+
1 row in set (0.05 sec)

+--------+--------+---------+---------+---------+
| vempno | vename | vsal    | vdeptno | vstatus |
+--------+--------+---------+---------+---------+
|   7698 | BLAKE  | 2850.00 |      30 | greater |
+--------+--------+---------+---------+---------+
1 row in set (0.06 sec)

+--------+--------+---------+---------+---------+
| vempno | vename | vsal    | vdeptno | vstatus |
+--------+--------+---------+---------+---------+
|   7782 | CLARK  | 2450.00 |      10 | lesser  |
+--------+--------+---------+---------+---------+
1 row in set (0.07 sec)

+--------+--------+---------+---------+---------+
| vempno | vename | vsal    | vdeptno | vstatus |
+--------+--------+---------+---------+---------+
|   7788 | SCOTT  | 3000.00 |      20 | greater |
+--------+--------+---------+---------+---------+
1 row in set (0.09 sec)

+--------+--------+---------+---------+---------+
| vempno | vename | vsal    | vdeptno | vstatus |
+--------+--------+---------+---------+---------+
|   7839 | KING   | 5000.00 |      10 | greater |
+--------+--------+---------+---------+---------+
1 row in set (0.09 sec)

+--------+--------+---------+---------+---------+
| vempno | vename | vsal    | vdeptno | vstatus |
+--------+--------+---------+---------+---------+
|   7844 | TURNER | 1500.00 |      30 | lesser  |
+--------+--------+---------+---------+---------+
1 row in set (0.10 sec)

+--------+--------+---------+---------+---------+
| vempno | vename | vsal    | vdeptno | vstatus |
+--------+--------+---------+---------+---------+
|   7876 | ADAMS  | 1100.00 |      20 | lesser  |
+--------+--------+---------+---------+---------+
1 row in set (0.10 sec)

+--------+--------+--------+---------+---------+
| vempno | vename | vsal   | vdeptno | vstatus |
+--------+--------+--------+---------+---------+
|   7900 | JAMES  | 950.00 |      30 | lesser  |
+--------+--------+--------+---------+---------+
1 row in set (0.12 sec)

+--------+--------+---------+---------+---------+
| vempno | vename | vsal    | vdeptno | vstatus |
+--------+--------+---------+---------+---------+
|   7902 | FORD   | 3000.00 |      20 | greater |
+--------+--------+---------+---------+---------+
1 row in set (0.12 sec)

+--------+--------+---------+---------+---------+
| vempno | vename | vsal    | vdeptno | vstatus |
+--------+--------+---------+---------+---------+
|   7934 | MILLER | 1300.00 |      10 | lesser  |
+--------+--------+---------+---------+---------+
1 row in set (0.14 sec)

Query OK, 0 rows affected (0.15 sec)


================================================= Question 8 =================================================


8. Write a procedure to update salary in emp table based on following rules.
Exp< =35 then no Update
Exp> 35 and <=38 then 20% of salary
Exp> 38 then 25% of salary


mysql> create procedure updatesal()
    begin
    declare vempno,vdeptno int;
    declare vename varchar(20);
    declare vhiredate date;
    declare vupdatesal, vsal decimal(9,2);

    declare vexp int;
    declare vset int default 0;
    declare empcur cursor for
    select empno,ename,hiredate,sal,deptno from emp;
    declare continue handler for not found set vset=1;
    open empcur;
    lable1 :loop
    fetch empcur into vempno,vename,vhiredate,vsal,vdeptno;
    if vset=1 then
    leave lable1;
    end if;
    set vexp=floor(datediff(curdate(),vhiredate))/365;
    if vexp <= 35 then
    select 'no update';
    elseif vexp <= 38 then
    
    set vupdatesal=vsal+0.20*vsal;
 
    else
    
    set vupdatesal = vsal + 0.25*vsal;
    
    end if;
    select vempno,vename,vdeptno,vsal,vupdatesal;
    end loop;
    close empcur;
    end//
Query OK, 0 rows affected (0.04 sec)

mysql> call updatesal//
+--------+--------+---------+---------+------------+
| vempno | vename | vdeptno | vsal    | vupdatesal |
+--------+--------+---------+---------+------------+
|   7369 | SMITH  |      20 | 1953.13 |    2441.41 |
+--------+--------+---------+---------+------------+
1 row in set (0.00 sec)

+--------+--------+---------+---------+------------+
| vempno | vename | vdeptno | vsal    | vupdatesal |
+--------+--------+---------+---------+------------+
|   7499 | ALLEN  |      30 | 3906.25 |    4882.81 |
+--------+--------+---------+---------+------------+
1 row in set (0.01 sec)

+--------+--------+---------+---------+------------+
| vempno | vename | vdeptno | vsal    | vupdatesal |
+--------+--------+---------+---------+------------+
|   7521 | WARD   |      30 | 3051.76 |    3814.70 |
+--------+--------+---------+---------+------------+
1 row in set (0.01 sec)

+--------+--------+---------+---------+------------+
| vempno | vename | vdeptno | vsal    | vupdatesal |
+--------+--------+---------+---------+------------+
|   7566 | JONES  |      20 | 7263.19 |    9078.99 |
+--------+--------+---------+---------+------------+
1 row in set (0.03 sec)

+--------+--------+---------+---------+------------+
| vempno | vename | vdeptno | vsal    | vupdatesal |
+--------+--------+---------+---------+------------+
|   7654 | MARTIN |      30 | 3051.76 |    3814.70 |
+--------+--------+---------+---------+------------+
1 row in set (0.04 sec)

+--------+--------+---------+---------+------------+
| vempno | vename | vdeptno | vsal    | vupdatesal |
+--------+--------+---------+---------+------------+
|   7698 | BLAKE  |      30 | 6958.01 |    8697.51 |
+--------+--------+---------+---------+------------+
1 row in set (0.04 sec)

+-----------+
| no update |
+-----------+
| no update |
+-----------+
1 row in set (0.04 sec)

+--------+--------+---------+---------+------------+
| vempno | vename | vdeptno | vsal    | vupdatesal |
+--------+--------+---------+---------+------------+
|   7700 | test1  |      30 | 1000.00 |    8697.51 |
+--------+--------+---------+---------+------------+
1 row in set (0.04 sec)

+--------+--------+---------+---------+------------+
| vempno | vename | vdeptno | vsal    | vupdatesal |
+--------+--------+---------+---------+------------+
|   7782 | CLARK  |      10 | 5981.45 |    7476.81 |
+--------+--------+---------+---------+------------+
1 row in set (0.05 sec)

+--------+--------+---------+---------+------------+
| vempno | vename | vdeptno | vsal    | vupdatesal |
+--------+--------+---------+---------+------------+
|   7788 | SCOTT  |      20 | 7324.23 |    9155.29 |
+--------+--------+---------+---------+------------+
1 row in set (0.05 sec)

+--------+--------+---------+----------+------------+
| vempno | vename | vdeptno | vsal     | vupdatesal |
+--------+--------+---------+----------+------------+
|   7839 | KING   |      10 | 12207.04 |   15258.80 |
+--------+--------+---------+----------+------------+
1 row in set (0.05 sec)

+--------+--------+---------+---------+------------+
| vempno | vename | vdeptno | vsal    | vupdatesal |
+--------+--------+---------+---------+------------+
|   7844 | TURNER |      30 | 3662.11 |    4577.64 |
+--------+--------+---------+---------+------------+
1 row in set (0.06 sec)

+--------+--------+---------+---------+------------+
| vempno | vename | vdeptno | vsal    | vupdatesal |
+--------+--------+---------+---------+------------+
|   7876 | ADAMS  |      20 | 2685.55 |    3356.94 |
+--------+--------+---------+---------+------------+
1 row in set (0.06 sec)

+--------+--------+---------+---------+------------+
| vempno | vename | vdeptno | vsal    | vupdatesal |
+--------+--------+---------+---------+------------+
|   7900 | JAMES  |      30 | 2319.35 |    2899.19 |
+--------+--------+---------+---------+------------+
1 row in set (0.06 sec)

+--------+--------+---------+---------+------------+
| vempno | vename | vdeptno | vsal    | vupdatesal |
+--------+--------+---------+---------+------------+
|   7902 | FORD   |      20 | 7324.23 |    9155.29 |
+--------+--------+---------+---------+------------+
1 row in set (0.07 sec)

+--------+--------+---------+---------+------------+
| vempno | vename | vdeptno | vsal    | vupdatesal |
+--------+--------+---------+---------+------------+
|   7934 | MILLER |      10 | 3173.83 |    3967.29 |
+--------+--------+---------+---------+------------+
1 row in set (0.07 sec)

Query OK, 0 rows affected (0.07 sec)


================================================= Question 9 =================================================

set global log_bin_trust_function_creators=1

9. Write a procedure and a function.
Function: write a function to calculate number of years of experience of employee.(note: 
pass hiredate as a parameter)
Procedure: Capture the value returned by the above function to calculate the additional
allowance for the emp based on the experience.
Additional Allowance = Year of experience x 3000
Calculate the additional allowance 
and store Empno, ename,Date of Joining, and Experience in
years and additional allowance in Emp_Allowance table.
create table emp_allowance(
empno int,
ename varchar(20),
hiredate date,
experience int,
allowance decimal(9,2));

================================================= Creating Function calyears() =================================================

mysql> create function calyears(phiredate date)returns int
    -> begin
    -> return floor(datediff(curdate(),phiredate)/365);
    -> end//
Query OK, 0 rows affected (0.05 sec)

mysql>
mysql>
mysql> select empno,ename,sal,hiredate,calyears(hiredate)
    -> from emp//
+-------+--------+---------+------------+--------------------+
| empno | ename  | sal     | hiredate   | calyears(hiredate) |
+-------+--------+---------+------------+--------------------+
|  7369 | SMITH  | 1000.00 | 1980-12-17 |                 41 |
|  7499 | ALLEN  | 2000.00 | 1981-02-20 |                 41 |
|  7521 | WARD   | 1562.50 | 1981-02-22 |                 41 |
|  7566 | JONES  | 3718.75 | 1981-04-02 |                 41 |
|  7654 | MARTIN | 1562.50 | 1981-09-28 |                 41 |
|  7698 | BLAKE  | 3562.50 | 1981-05-01 |                 41 |
|  7700 | test1  | 1000.00 | 2022-11-05 |                  0 |
|  7782 | CLARK  | 3062.50 | 1981-06-09 |                 41 |
|  7788 | SCOTT  | 3750.00 | 1982-12-09 |                 39 |
|  7839 | KING   | 6250.00 | 1981-11-17 |                 41 |
|  7844 | TURNER | 1875.00 | 1981-09-08 |                 41 |
|  7876 | ADAMS  | 1375.00 | 1983-01-12 |                 39 |
|  7900 | JAMES  | 1187.50 | 1981-12-03 |                 40 |
|  7902 | FORD   | 3750.00 | 1981-12-03 |                 40 |
|  7934 | MILLER | 1625.00 | 1982-01-23 |                 40 |
+-------+--------+---------+------------+--------------------+
15 rows in set (0.02 sec)


================================================= Creating procedure updatesal_2 =================================================

mysql> create procedure updatesal_2()
    ->     begin
    ->     declare vempno int;
    ->     declare vename varchar(20);
    ->     declare vhiredate date;
    ->     declare vsal, vallowance decimal(9,2);
    ->     declare vexp int;
    ->     declare vset int default 0;
    ->     declare updatecur cursor for
    ->     select empno,ename,hiredate,sal from emp;
    ->     declare continue handler for not found set vset=1;
    ->     open updatecur;
    ->     lable1 :loop
    ->     fetch updatecur into vempno,vename,vhiredate,vsal;
    ->     if vset=1 then
    ->     leave lable1;
    ->     end if;
    ->
    ->     set vexp=calyears(vhiredate);
    ->     set vallowance=vexp*3000;
    ->     insert into emp_allowance values(vempno,vename,vhiredate,vexp,vallowance);
    ->
    ->     end loop;
    ->     close updatecur;
    ->     end//
Query OK, 0 rows affected (0.04 sec)


================================================= Calling procedure updatesal_2 =================================================

mysql> call updatesal_2//
Query OK, 0 rows affected (0.27 sec)

================================================= The values are inside emp_allowance table =================================================

mysql> select * from emp_allowance//
+-------+--------+------------+------------+-----------+
| empno | ename  | hiredate   | experience | allowance |
+-------+--------+------------+------------+-----------+
|  7369 | SMITH  | 1980-12-17 |         41 | 123000.00 |
|  7499 | ALLEN  | 1981-02-20 |         41 | 123000.00 |
|  7521 | WARD   | 1981-02-22 |         41 | 123000.00 |
|  7566 | JONES  | 1981-04-02 |         41 | 123000.00 |
|  7654 | MARTIN | 1981-09-28 |         41 | 123000.00 |
|  7698 | BLAKE  | 1981-05-01 |         41 | 123000.00 |
|  7700 | test1  | 2022-11-05 |          0 |      0.00 |
|  7782 | CLARK  | 1981-06-09 |         41 | 123000.00 |
|  7788 | SCOTT  | 1982-12-09 |         39 | 117000.00 |
|  7839 | KING   | 1981-11-17 |         41 | 123000.00 |
|  7844 | TURNER | 1981-09-08 |         41 | 123000.00 |
|  7876 | ADAMS  | 1983-01-12 |         39 | 117000.00 |
|  7900 | JAMES  | 1981-12-03 |         40 | 120000.00 |
|  7902 | FORD   | 1981-12-03 |         40 | 120000.00 |
|  7934 | MILLER | 1982-01-23 |         40 | 120000.00 |
+-------+--------+------------+------------+-----------+
15 rows in set (0.00 sec)


================================================= Question 10 =================================================


10. Write a function to compute the following. Function should take sal and hiredate as i/p and return the cost to company.
DA = 15% Salary, HRA= 20% of Salary, TA= 8% of Salary.
Special Allowance will be decided based on the service in the company.
< 1 Year Nil
>=1 Year< 2 Year 10% of Salary
>=2 Year< 4 Year 20% of Salary
>4 Year 30% of Salary

mysql> create function calculate_allowance(psal decimal(9,2),phiredate date) returns decimal(9,2)
    ->
    -> begin
    ->
    -> declare netsal,vspecial_allowance decimal(9,2);
    ->
    -> set netsal = (psal*1.15)+(psal*1.20)-(psal*1.08);
    ->
    -> if calyears(phiredate)<1 then
    -> set vspecial_allowance = 0;
    ->
    -> elseif calyears(phiredate)<2 then
    -> set vspecial_allowance = 1.10 * psal;
    ->
    -> elseif calyears(phiredate)<4 then
    -> set vspecial_allowance = 1.20 * psal;
    ->
    -> else
    -> set vspecial_allowance = 1.30 * psal;
    ->
    -> end if;
    -> return netsal + vspecial_allowance;
    -> end//
Query OK, 0 rows affected (0.04 sec)


mysql> select empno , ename , sal , hiredate , calculate_allowance(sal , hiredate)
    -> from emp;
    -> //
+-------+--------+---------+------------+-------------------------------------+
| empno | ename  | sal     | hiredate   | calculate_allowance(sal , hiredate) |
+-------+--------+---------+------------+-------------------------------------+
|  7369 | SMITH  | 1000.00 | 1980-12-17 |                             2570.00 |
|  7499 | ALLEN  | 2000.00 | 1981-02-20 |                             5140.00 |
|  7521 | WARD   | 1562.50 | 1981-02-22 |                             4015.63 |
|  7566 | JONES  | 3718.75 | 1981-04-02 |                             9557.19 |
|  7654 | MARTIN | 1562.50 | 1981-09-28 |                             4015.63 |
|  7698 | BLAKE  | 3562.50 | 1981-05-01 |                             9155.63 |
|  7700 | test1  | 1000.00 | 2022-11-05 |                             1270.00 |
|  7782 | CLARK  | 3062.50 | 1981-06-09 |                             7870.63 |
|  7788 | SCOTT  | 3750.00 | 1982-12-09 |                             9637.50 |
|  7839 | KING   | 6250.00 | 1981-11-17 |                            16062.50 |
|  7844 | TURNER | 1875.00 | 1981-09-08 |                             4818.75 |
|  7876 | ADAMS  | 1375.00 | 1983-01-12 |                             3533.75 |
|  7900 | JAMES  | 1187.50 | 1981-12-03 |                             3051.88 |
|  7902 | FORD   | 3750.00 | 1981-12-03 |                             9637.50 |
|  7934 | MILLER | 1625.00 | 1982-01-23 |                             4176.25 |
+-------+--------+---------+------------+-------------------------------------+
15 rows in set (0.00 sec)


     + ====================================================================================================================================================================== +

     |          ===================================x-x-x-x-x-x-x-x-x-x-x-x-x-x-x-x-x-x-x-x-x-x-x-x-x ================================================                         |                                
                                       ======================== Trigger Assigenments ========================
     |          ===================================x-x-x-x-x-x-x-x-x-x-x-x-x-x-x-x-x-x-x-x-x-x-x-x-x=================================================                         |

     + ====================================================================================================================================================================== +


================================================= Question 1 Trigger ===================================================

Q2. Write trigger
1. Write a tigger to store the old salary details in Emp _Back (Emp _Back has the same structure as emp table without any
constraint) table.
(note :create emp_back table before writing trigger)
----- to create emp_back table
create table emp_back(
empno int,
ename varchar(20),
oldsal decimal(9,2),
newsal decimal(9,2)
)
(note :
execute procedure written in Q8 and
check the entries in EMP_back table after execution of the procedure)


================================================= Creating table emp_back =========================================================================

mysql> create table emp_back(
    empno int,
    ename varchar(20),
    oldsal decimal(9,2),
    newsal decimal(9,2)
    );
Query OK, 0 rows affected (0.11 sec)

mysql> set autocommit=0;
Query OK, 0 rows affected (0.00 sec)

================================================= Creating trigger for insert record (ins_empback) =================================================
mysql> create trigger ins_empback
    before insert on emp
    for each row
    begin
    insert into emp_back values(new.empno,new.ename,new.sal,new.sal);
    end//
Query OK, 0 rows affected (0.05 sec)

================================================= Creating trigger for update record (update_empback) =================================================

mysql> create trigger update_empback
    -> before update on emp
    -> for each row
    -> begin
    -> insert into emp_back values(old.empno,old.ename,old.sal,new.sal);
    -> end//
Query OK, 0 rows affected (0.06 sec)


================================================= Creating trigger for deleting record (del_emp) =================================================
mysql> create trigger del_emp
    -> after delete on emp
    -> for each row
    -> begin
    -> insert into emp_back values(old.empno,old.ename,old.sal,null,old.job,null
);
    -> end//
Query OK, 0 rows affected (0.14 sec)


================================================= Calling procedure updatesal ===================================================================

mysql> call updatesal//
+--------+--------+---------+---------+
| vempno | vename | vdeptno | vsal    |
+--------+--------+---------+---------+
|   7369 | SMITH  |      20 | 1250.00 |
+--------+--------+---------+---------+
1 row in set (0.01 sec)

+--------+--------+---------+---------+
| vempno | vename | vdeptno | vsal    |
+--------+--------+---------+---------+
|   7499 | ALLEN  |      30 | 2500.00 |
+--------+--------+---------+---------+
1 row in set (0.01 sec)

+--------+--------+---------+---------+
| vempno | vename | vdeptno | vsal    |
+--------+--------+---------+---------+
|   7521 | WARD   |      30 | 1953.13 |
+--------+--------+---------+---------+
1 row in set (0.01 sec)

+--------+--------+---------+---------+
| vempno | vename | vdeptno | vsal    |
+--------+--------+---------+---------+
|   7566 | JONES  |      20 | 4648.44 |
+--------+--------+---------+---------+
1 row in set (0.02 sec)

+--------+--------+---------+---------+
| vempno | vename | vdeptno | vsal    |
+--------+--------+---------+---------+
|   7654 | MARTIN |      30 | 1953.13 |
+--------+--------+---------+---------+
1 row in set (0.02 sec)

+--------+--------+---------+---------+
| vempno | vename | vdeptno | vsal    |
+--------+--------+---------+---------+
|   7698 | BLAKE  |      30 | 4453.13 |
+--------+--------+---------+---------+
1 row in set (0.02 sec)

+-----------+
| no update |
+-----------+
| no update |
+-----------+
1 row in set (0.02 sec)

+--------+--------+---------+---------+
| vempno | vename | vdeptno | vsal    |
+--------+--------+---------+---------+
|   7700 | test1  |      30 | 1000.00 |
+--------+--------+---------+---------+
1 row in set (0.03 sec)

+--------+--------+---------+---------+
| vempno | vename | vdeptno | vsal    |
+--------+--------+---------+---------+
|   7782 | CLARK  |      10 | 3828.13 |
+--------+--------+---------+---------+
1 row in set (0.03 sec)

+--------+--------+---------+---------+
| vempno | vename | vdeptno | vsal    |
+--------+--------+---------+---------+
|   7788 | SCOTT  |      20 | 4687.50 |
+--------+--------+---------+---------+
1 row in set (0.03 sec)

+--------+--------+---------+---------+
| vempno | vename | vdeptno | vsal    |
+--------+--------+---------+---------+
|   7839 | KING   |      10 | 7812.50 |
+--------+--------+---------+---------+
1 row in set (0.03 sec)

+--------+--------+---------+---------+
| vempno | vename | vdeptno | vsal    |
+--------+--------+---------+---------+
|   7844 | TURNER |      30 | 2343.75 |
+--------+--------+---------+---------+
1 row in set (0.04 sec)

+--------+--------+---------+---------+
| vempno | vename | vdeptno | vsal    |
+--------+--------+---------+---------+
|   7876 | ADAMS  |      20 | 1718.75 |
+--------+--------+---------+---------+
1 row in set (0.04 sec)

+--------+--------+---------+---------+
| vempno | vename | vdeptno | vsal    |
+--------+--------+---------+---------+
|   7900 | JAMES  |      30 | 1484.38 |
+--------+--------+---------+---------+
1 row in set (0.04 sec)

+--------+--------+---------+---------+
| vempno | vename | vdeptno | vsal    |
+--------+--------+---------+---------+
|   7902 | FORD   |      20 | 4687.50 |
+--------+--------+---------+---------+
1 row in set (0.04 sec)

+--------+--------+---------+---------+
| vempno | vename | vdeptno | vsal    |
+--------+--------+---------+---------+
|   7934 | MILLER |      10 | 2031.25 |
+--------+--------+---------+---------+
1 row in set (0.04 sec)

Query OK, 0 rows affected (0.05 sec)


================================================= Checking changes  ===================================================================

mysql> select * from emp_back;
    -> //
+-------+--------+---------+---------+
| empno | ename  | oldsal  | newsal  |
+-------+--------+---------+---------+
|  7369 | SMITH  | 1250.00 | 1562.50 |
|  7499 | ALLEN  | 2500.00 | 3125.00 |
|  7521 | WARD   | 1953.13 | 2441.41 |
|  7566 | JONES  | 4648.44 | 5810.55 |
|  7654 | MARTIN | 1953.13 | 2441.41 |
|  7698 | BLAKE  | 4453.13 | 5566.41 |
|  7782 | CLARK  | 3828.13 | 4785.16 |
|  7788 | SCOTT  | 4687.50 | 5859.38 |
|  7839 | KING   | 7812.50 | 9765.63 |
|  7844 | TURNER | 2343.75 | 2929.69 |
|  7876 | ADAMS  | 1718.75 | 2148.44 |
|  7900 | JAMES  | 1484.38 | 1855.48 |
|  7902 | FORD   | 4687.50 | 5859.38 |
|  7934 | MILLER | 2031.25 | 2539.06 |
+-------+--------+---------+---------+
14 rows in set (0.00 sec)


================================================= Question 2 Trigger ======================================================


2. Write a trigger which add entry in audit table when user tries to insert or delete records in employee table store empno,name,username and date on which operation performed and which action is done insert or delete. in emp_audit table.
create table before writing trigger.

================================================= Creating table emp_audit =================================================   
create table empaudit(
empno int;
ename varchar(20),
username varchar(20);
chdate date;
action varchar(20)
);

================================================= Creating trigger for insert record =================================================

mysql> create trigger ins_empaudit
    -> before insert on emp
    -> for each row
    -> begin
    -> insert into empaudit values(new.empno,new.ename,current_user(),'before insert',curdate());
    -> end //



Query OK, 0 rows affected (0.04 sec)
================================================= Creating trigger for update record =================================================

mysql> create trigger update_empaudit
    -> before update on emp
    -> for each row
    -> begin
    -> insert into empaudit values(new.empno,new.ename,current_user(),'before update',curdate());
    -> end //
Query OK, 0 rows affected (0.19 sec)


================================================= Creating trigger for delete record =================================================

mysql> create trigger del_empaudit
    -> before delete on emp
    -> for each row
    -> begin
    -> insert into empaudit values(old.empno,old.ename,current_user(),'before delete',curdate());
    -> end //
Query OK, 0 rows affected (0.33 sec)




mysql> call updatesal//
+--------+--------+---------+---------+------------+
| vempno | vename | vdeptno | vsal    | vupdatesal |
+--------+--------+---------+---------+------------+
|   7369 | SMITH  |      20 | 1953.13 |    2441.41 |
+--------+--------+---------+---------+------------+
1 row in set (0.00 sec)

+--------+--------+---------+---------+------------+
| vempno | vename | vdeptno | vsal    | vupdatesal |
+--------+--------+---------+---------+------------+
|   7499 | ALLEN  |      30 | 3906.25 |    4882.81 |
+--------+--------+---------+---------+------------+
1 row in set (0.01 sec)

+--------+--------+---------+---------+------------+
| vempno | vename | vdeptno | vsal    | vupdatesal |
+--------+--------+---------+---------+------------+
|   7521 | WARD   |      30 | 3051.76 |    3814.70 |
+--------+--------+---------+---------+------------+
1 row in set (0.01 sec)

+--------+--------+---------+---------+------------+
| vempno | vename | vdeptno | vsal    | vupdatesal |
+--------+--------+---------+---------+------------+
|   7566 | JONES  |      20 | 7263.19 |    9078.99 |
+--------+--------+---------+---------+------------+
1 row in set (0.03 sec)

+--------+--------+---------+---------+------------+
| vempno | vename | vdeptno | vsal    | vupdatesal |
+--------+--------+---------+---------+------------+
|   7654 | MARTIN |      30 | 3051.76 |    3814.70 |
+--------+--------+---------+---------+------------+
1 row in set (0.04 sec)

+--------+--------+---------+---------+------------+
| vempno | vename | vdeptno | vsal    | vupdatesal |
+--------+--------+---------+---------+------------+
|   7698 | BLAKE  |      30 | 6958.01 |    8697.51 |
+--------+--------+---------+---------+------------+
1 row in set (0.04 sec)

+-----------+
| no update |
+-----------+
| no update |
+-----------+
1 row in set (0.04 sec)

+--------+--------+---------+---------+------------+
| vempno | vename | vdeptno | vsal    | vupdatesal |
+--------+--------+---------+---------+------------+
|   7700 | test1  |      30 | 1000.00 |    8697.51 |
+--------+--------+---------+---------+------------+
1 row in set (0.04 sec)

+--------+--------+---------+---------+------------+
| vempno | vename | vdeptno | vsal    | vupdatesal |
+--------+--------+---------+---------+------------+
|   7782 | CLARK  |      10 | 5981.45 |    7476.81 |
+--------+--------+---------+---------+------------+
1 row in set (0.05 sec)

+--------+--------+---------+---------+------------+
| vempno | vename | vdeptno | vsal    | vupdatesal |
+--------+--------+---------+---------+------------+
|   7788 | SCOTT  |      20 | 7324.23 |    9155.29 |
+--------+--------+---------+---------+------------+
1 row in set (0.05 sec)

+--------+--------+---------+----------+------------+
| vempno | vename | vdeptno | vsal     | vupdatesal |
+--------+--------+---------+----------+------------+
|   7839 | KING   |      10 | 12207.04 |   15258.80 |
+--------+--------+---------+----------+------------+
1 row in set (0.05 sec)

+--------+--------+---------+---------+------------+
| vempno | vename | vdeptno | vsal    | vupdatesal |
+--------+--------+---------+---------+------------+
|   7844 | TURNER |      30 | 3662.11 |    4577.64 |
+--------+--------+---------+---------+------------+
1 row in set (0.06 sec)

+--------+--------+---------+---------+------------+
| vempno | vename | vdeptno | vsal    | vupdatesal |
+--------+--------+---------+---------+------------+
|   7876 | ADAMS  |      20 | 2685.55 |    3356.94 |
+--------+--------+---------+---------+------------+
1 row in set (0.06 sec)

+--------+--------+---------+---------+------------+
| vempno | vename | vdeptno | vsal    | vupdatesal |
+--------+--------+---------+---------+------------+
|   7900 | JAMES  |      30 | 2319.35 |    2899.19 |
+--------+--------+---------+---------+------------+
1 row in set (0.06 sec)

+--------+--------+---------+---------+------------+
| vempno | vename | vdeptno | vsal    | vupdatesal |
+--------+--------+---------+---------+------------+
|   7902 | FORD   |      20 | 7324.23 |    9155.29 |
+--------+--------+---------+---------+------------+
1 row in set (0.07 sec)

+--------+--------+---------+---------+------------+
| vempno | vename | vdeptno | vsal    | vupdatesal |
+--------+--------+---------+---------+------------+
|   7934 | MILLER |      10 | 3173.83 |    3967.29 |
+--------+--------+---------+---------+------------+
1 row in set (0.07 sec)

Query OK, 0 rows affected (0.07 sec)


mysql> select * from empaudit;
    -> //
+-------+--------+----------------+---------------+------------+
| empno | ename  | username       | action        | chdate     |
+-------+--------+----------------+---------------+------------+
|  7369 | SMITH  | root@localhost | before update | 2022-11-09 |
|  7499 | ALLEN  | root@localhost | before update | 2022-11-09 |
|  7521 | WARD   | root@localhost | before update | 2022-11-09 |
|  7566 | JONES  | root@localhost | before update | 2022-11-09 |
|  7654 | MARTIN | root@localhost | before update | 2022-11-09 |
|  7698 | BLAKE  | root@localhost | before update | 2022-11-09 |
|  7782 | CLARK  | root@localhost | before update | 2022-11-09 |
|  7788 | SCOTT  | root@localhost | before update | 2022-11-09 |
|  7839 | KING   | root@localhost | before update | 2022-11-09 |
|  7844 | TURNER | root@localhost | before update | 2022-11-09 |
|  7876 | ADAMS  | root@localhost | before update | 2022-11-09 |
|  7900 | JAMES  | root@localhost | before update | 2022-11-09 |
|  7902 | FORD   | root@localhost | before update | 2022-11-09 |
|  7934 | MILLER | root@localhost | before update | 2022-11-09 |
+-------+--------+----------------+---------------+------------+
14 rows in set (0.00 sec)



================================================= Question 3 Trigger =================================================


3. Create table vehicle_history. Write a trigger to store old vehicleprice and new vehicle price in history table before you update price in vehicle table
(note: use vehicle table).
create table vehicle_history(
vno int,
vname varchar(20),
oldprice decimal(9,2),
newprice decimal(9,2),
chdate date,
username varchar(20)
);

=========================================== Checking contents of vehicle table =======================================

mysql> select * from vehicle//
+-----+------------+-----------+--------------------+
| vid | vname      | price     | des                |
+-----+------------+-----------+--------------------+
|   1 | Activa     |  80000.00 | No mileage         |
|   2 | Santro     | 800000.00 | Good family car    |
|   3 | Motor bike | 100000.00 | No motor available |
+-----+------------+-----------+--------------------+
3 rows in set (0.00 sec)

=========================================== Creating trigger of update_vehicle_history =======================================

mysql> create trigger update_vehicle_history
    -> before update on vehicle
    -> for each row
    -> begin
    -> insert into vehicle_history values(old.vid,old.vname,old.price,new.price,
curdate(),current_user());
    -> end//
Query OK, 0 rows affected (0.10 sec)

=========================================== updateing value of price of activa ==============================================

mysql> update vehicle
    -> set price=50000
    -> where vname='activa'//
Query OK, 1 row affected (0.03 sec)
Rows matched: 1  Changed: 1  Warnings: 0

=========================================== Checking trigger for changes made in table =======================================

mysql> select * from vehicle_history//
+------+--------+----------+----------+------------+----------------+
| vno  | vname  | oldprice | newprice | chdate     | username       |
+------+--------+----------+----------+------------+----------------+
|    1 | Activa | 80000.00 | 50000.00 | 2022-11-09 | root@localhost |
+------+--------+----------+----------+------------+----------------+
1 row in set (0.00 sec)


























