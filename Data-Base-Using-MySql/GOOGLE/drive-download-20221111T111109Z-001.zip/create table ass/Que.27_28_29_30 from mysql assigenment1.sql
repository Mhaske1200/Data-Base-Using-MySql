﻿ 

 *********************************************   Q   27  **********************************************************************
 
  27. list empcode,empno,name and job for each employee. (note :empcode is 3 to 5 characters
from name and last 2 characters of job)



mysql> select ename,job ,concat(substr(ename,3,3),substr(job,length(job)-1,2))"EMP CODE"
    -> from emp;
	
	
	/////  substr(ename,3,3)=== takes characters from ename starting from  3 position and taking 3 characters ahead of it /////
	
	/////  substr(job,length(job)-1,2)=== takes length of job  and subtract 1,2 and get the last and second last positions of characters/////

mysql> select ename,job ,concat(substr(ename,3,3),substr(job,length(job)-1,2))"EMP CODE"
    -> from emp;
+--------+-----------+----------+
| ename  | job       | EMP CODE |
+--------+-----------+----------+
| SMITH  | CLERK     | ITHRK    |
| ALLEN  | SALESMAN  | LENAN    |
| WARD   | SALESMAN  | RDAN     |
| JONES  | MANAGER   | NESER    |
| MARTIN | SALESMAN  | RTIAN    |
| BLAKE  | MANAGER   | AKEER    |
| CLARK  | MANAGER   | ARKER    |
| SCOTT  | ANALYST   | OTTST    |
| KING   | PRESIDENT | NGNT     |
| TURNER | SALESMAN  | RNEAN    |
| ADAMS  | CLERK     | AMSRK    |
| JAMES  | CLERK     | MESRK    |
| FORD   | ANALYST   | RDST     |
| MILLER | CLERK     | LLERK    |
+--------+-----------+----------+
14 rows in set (0.00 sec)

*********************************************   Q   28 ************************************

   28. display thousand separator and $ symbol for commission if it is null then display it as 0 for all
employees whose name starts with A and ends with N


mysql> select ename,comm,sal,concat(format(ifnull(comm,0),3),'$')
    -> from emp
    -> where ename REGEXP '^a.*n$';
+-------+--------+---------+--------------------------------------+
| ename | comm   | sal     | concat(format(ifnull(comm,0),3),'$') |
+-------+--------+---------+--------------------------------------+
| ALLEN | 300.00 | 1600.00 | 300.000$                             |
+-------+--------+---------+--------------------------------------+
1 row in set (0.09 sec)

mysql> select ename,comm,sal,concat(format(ifnull(comm,0),3),'$')
    -> from emp;
+--------+---------+---------+--------------------------------------+
| ename  | comm    | sal     | concat(format(ifnull(comm,0),3),'$') |
+--------+---------+---------+--------------------------------------+
| SMITH  |    NULL |  800.00 | 0.000$                               |
| ALLEN  |  300.00 | 1600.00 | 300.000$                             |
| WARD   |  500.00 | 1250.00 | 500.000$                             |
| JONES  |    NULL | 2975.00 | 0.000$                               |
| MARTIN | 1400.00 | 1250.00 | 1,400.000$                           |
| BLAKE  |    NULL | 2850.00 | 0.000$                               |
| CLARK  |    NULL | 2450.00 | 0.000$                               |
| SCOTT  |    NULL | 3000.00 | 0.000$                               |
| KING   |    NULL | 5000.00 | 0.000$                               |
| TURNER |    0.00 | 1500.00 | 0.000$                               |
| ADAMS  |    NULL | 1100.00 | 0.000$                               |
| JAMES  |    NULL |  950.00 | 0.000$                               |
| FORD   |    NULL | 3000.00 | 0.000$                               |
| MILLER |    NULL | 1300.00 | 0.000$                               |
+--------+---------+---------+--------------------------------------+
14 rows in set (0.00 sec)

mysql> select ename,comm,sal,concat(format(ifnull(comm,0),3),'$')
    -> from emp
    -> where ename REGEXP '^m.*n$';
+--------+---------+---------+--------------------------------------+
| ename  | comm    | sal     | concat(format(ifnull(comm,0),3),'$') |
+--------+---------+---------+--------------------------------------+
| MARTIN | 1400.00 | 1250.00 | 1,400.000$                           |
+--------+---------+---------+--------------------------------------+
1 row in set (0.00 sec)


*********************************************   Q   29 ************************************

29. Display empid,name,sal,comm,remark Remark should base on following conditions
comm >= 600 "excellent Keep it up"
if it < 600 or not null "good"
otherwise "Need improvement"

mysql>  select empno,ename,sal,comm,
    -> case when comm>=600 then 'excellent keep it up'
    -> when comm < 600 or comm is not  null then 'good'
    -> else 'need improvement' end remark
    -> from emp;
+-------+--------+---------+---------+----------------------+
| empno | ename  | sal     | comm    | remark               |
+-------+--------+---------+---------+----------------------+
|  7369 | SMITH  |  800.00 |    NULL | need improvement     |
|  7499 | ALLEN  | 1600.00 |  300.00 | good                 |
|  7521 | WARD   | 1250.00 |  500.00 | good                 |
|  7566 | JONES  | 2975.00 |    NULL | need improvement     |
|  7654 | MARTIN | 1250.00 | 1400.00 | excellent keep it up |
|  7698 | BLAKE  | 2850.00 |    NULL | need improvement     |
|  7782 | CLARK  | 2450.00 |    NULL | need improvement     |
|  7788 | SCOTT  | 3000.00 |    NULL | need improvement     |
|  7839 | KING   | 5000.00 |    NULL | need improvement     |
|  7844 | TURNER | 1500.00 |    0.00 | good                 |
|  7876 | ADAMS  | 1100.00 |    NULL | need improvement     |
|  7900 | JAMES  |  950.00 |    NULL | need improvement     |
|  7902 | FORD   | 3000.00 |    NULL | need improvement     |
|  7934 | MILLER | 1300.00 |    NULL | need improvement     |
+-------+--------+---------+---------+----------------------+
14 rows in set (0.02 sec)

*********************************************   Q   30 ************************************

 30. Display empid, name, deptno and department name by using following conditions.
dept 10 then "Hr"
if 20 then "Admin"
if 30 then "accounts"
otherwise purchase

mysql>  select empno,ename,deptno,
    -> case when deptno=10 then 'HR'
    -> when deptno=20 then 'Admin'
    -> when deptno=30 then 'Account'
    -> else 'Purchase' end remark
    -> from emp;
+-------+--------+--------+---------+
| empno | ename  | deptno | remark  |
+-------+--------+--------+---------+
|  7369 | SMITH  |     20 | Admin   |
|  7499 | ALLEN  |     30 | Account |
|  7521 | WARD   |     30 | Account |
|  7566 | JONES  |     20 | Admin   |
|  7654 | MARTIN |     30 | Account |
|  7698 | BLAKE  |     30 | Account |
|  7782 | CLARK  |     10 | HR      |
|  7788 | SCOTT  |     20 | Admin   |
|  7839 | KING   |     10 | HR      |
|  7844 | TURNER |     30 | Account |
|  7876 | ADAMS  |     20 | Admin   |
|  7900 | JAMES  |     30 | Account |
|  7902 | FORD   |     20 | Admin   |
|  7934 | MILLER |     10 | HR      |
+-------+--------+--------+---------+
14 rows in set (0.00 sec)