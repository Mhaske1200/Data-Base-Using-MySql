﻿32. Create following tables Student, Course
Student (sid,sname) ---------------- sid ---primary key
Course(cid,cname)-------------- cid ---primary key
Marks(studid,courseid,marks)
Sample data for marks table
studid,courseid,marks
 1 1 99
 1 3 98
 2 1 95
 2 2 97
create table marks(
studid number,
courseid number,
marks number,
constraint pk primary key(studid,courseid),
constraint fk_sid foreign key (studid) references student(sid) on delete cascade,
constraint fk_cid foreign key (courseid) references course(cid)
)

********************************************* SOLUTION *************************************************************************************

Note:- Database use for this is createtableass.
       createtableass is newly created.



mysql> create table Student
    -> (sid int primary key auto_increment,
    -> sname varchar(20) not null);
Query OK, 0 rows affected (0.76 sec)


mysql> create table course;
ERROR 4028 (HY000): A table must have at least one visible column.
mysql> create table course(
    -> cid int primary key,
    -> cname varchar(20)not null);
Query OK, 0 rows affected (0.18 sec)


mysql> create table marks
    -> (studid int ,
    -> courseid int,
    -> marks double check(marks between 0 and 100),
    -> constraint pk primary key(studid,courseid),
    -> constraint fk_sid foreign key(studid) references student(sid)on delete cascade,
    -> constraint fk_cid foreign key(courseid) references course(cid));
Query OK, 0 rows affected (0.10 sec)

mysql> desc marks;
+----------+--------+------+-----+---------+-------+
| Field    | Type   | Null | Key | Default | Extra |
+----------+--------+------+-----+---------+-------+
| studid   | int    | NO   | PRI | NULL    |       |
| courseid | int    | NO   | PRI | NULL    |       |
| marks    | double | YES  |     | NULL    |       |
+----------+--------+------+-----+---------+-------+
3 rows in set (0.00 sec)



mysql> insert into student(sname)values('suraj');
Query OK, 1 row affected (0.71 sec)

mysql> select*
    -> from student;
+-----+-------+
| sid | sname |
+-----+-------+
|   1 | suraj |
+-----+-------+
1 row in set (0.00 sec)

mysql> insert into student(sname)values('suraj'),('shubham'),('sanket'),('abhi');
Query OK, 4 rows affected (0.11 sec)
Records: 4  Duplicates: 0  Warnings: 0


mysql> select * from student;
+-----+---------+
| sid | sname   |
+-----+---------+
|   1 | suraj   |
|   2 | suraj   |
|   3 | shubham |
|   4 | sanket  |
|   5 | abhi    |
+-----+---------+
5 rows in set (0.00 sec)

********************************IN THE ABOVE TABLE SURAJ ENTRY IS DOUBLED SO DELETE IT ************************************************* 

mysql> delete from table student
    -> ^C
mysql> delete from student where sid=2;
Query OK, 1 row affected (0.16 sec)

mysql> select * from student;
+-----+---------+
| sid | sname   |
+-----+---------+
|   1 | suraj   |
|   3 | shubham |
|   4 | sanket  |
|   5 | abhi    |
+-----+---------+
4 rows in set (0.00 sec)

******************************** INSERTING KASHI RECORDS IN PLACE OF SURAJ RECORD *********************************************************
mysql> insert into student(sid,sname)values(2,'kashi');
Query OK, 1 row affected (0.14 sec)

mysql> select*from student;
+-----+---------+
| sid | sname   |
+-----+---------+
|   1 | suraj   |
|   2 | kashi   |
|   3 | shubham |
|   4 | sanket  |
|   5 | abhi    |
+-----+---------+
5 rows in set (0.00 sec)

mysql> insert into course(cid,cname)values(1,'Java'),(2,'Data'),(3,'C+');
Query OK, 3 rows affected (0.61 sec)
Records: 3  Duplicates: 0  Warnings: 0

mysql> select*from course;
+-----+-------+
| cid | cname |
+-----+-------+
|   1 | Java  |
|   2 | Data  |
|   3 | C+    |
+-----+-------+
3 rows in set (0.00 sec)

***************************************  INSERTING DATA OF MARKS TABLE ******************************************************************


mysql> insert into marks(studid,courseid,marks)values(1,'1',99),(1,'3',98),(2,'1',95),(2,'2',97);
Query OK, 4 rows affected (0.03 sec)
Records: 4  Duplicates: 0  Warnings: 0

mysql> select*from marks;
+--------+----------+-------+
| studid | courseid | marks |
+--------+----------+-------+
|      1 |        1 |    99 |
|      1 |        3 |    98 |
|      2 |        1 |    95 |
|      2 |        2 |    97 |
+--------+----------+-------+
4 rows in set (0.00 sec)


