﻿




32. Create following tables Student, Course
Student (sid,sname) ---------------- sid ---primary key
Course(cid,cname)-------------- cid ---primary key
Marks(studid,courseid,marks)
Sample data for marks table
studid,courseid,marks
 1 1 99
 1 3 98
 2 1 95
 2 2 97
create table marks(
studid number,
courseid number,
marks number,
constraint pk primary key(studid,courseid),
constraint fk_sid foreign key (studid) references student(sid) on delete cascade,
constraint fk_cid foreign key (courseid) references course(cid)
)

********************************************* SOLUTION *************************************************************************************

Note:- Database use for this is createtableass.
       createtableass is newly created.



mysql> create table Student
    -> (sid int primary key auto_increment,
    -> sname varchar(20) not null);
Query OK, 0 rows affected (0.76 sec)


mysql> create table course;
ERROR 4028 (HY000): A table must have at least one visible column.
mysql> create table course(
    -> cid int primary key,
    -> cname varchar(20)not null);
Query OK, 0 rows affected (0.18 sec)


mysql> create table marks
    -> (studid int ,
    -> courseid int,
    -> marks double check(marks between 0 and 100),
    -> constraint pk primary key(studid,courseid),
    -> constraint fk_sid foreign key(studid) references student(sid)on delete cascade,
    -> constraint fk_cid foreign key(courseid) references course(cid));
Query OK, 0 rows affected (0.10 sec)

mysql> desc marks;
+----------+--------+------+-----+---------+-------+
| Field    | Type   | Null | Key | Default | Extra |
+----------+--------+------+-----+---------+-------+
| studid   | int    | NO   | PRI | NULL    |       |
| courseid | int    | NO   | PRI | NULL    |       |
| marks    | double | YES  |     | NULL    |       |
+----------+--------+------+-----+---------+-------+
3 rows in set (0.00 sec)



mysql> insert into student(sname)values('suraj');
Query OK, 1 row affected (0.71 sec)

mysql> select*
    -> from student;
+-----+-------+
| sid | sname |
+-----+-------+
|   1 | suraj |
+-----+-------+
1 row in set (0.00 sec)

mysql> insert into student(sname)values('suraj'),('shubham'),('sanket'),('abhi');
Query OK, 4 rows affected (0.11 sec)
Records: 4  Duplicates: 0  Warnings: 0


mysql> select * from student;
+-----+---------+
| sid | sname   |
+-----+---------+
|   1 | suraj   |
|   2 | suraj   |
|   3 | shubham |
|   4 | sanket  |
|   5 | abhi    |
+-----+---------+
5 rows in set (0.00 sec)

********************************IN THE ABOVE TABLE SURAJ ENTRY IS DOUBLED SO DELETE IT ************************************************* 

mysql> delete from table student
    -> ^C
mysql> delete from student where sid=2;
Query OK, 1 row affected (0.16 sec)

mysql> select * from student;
+-----+---------+
| sid | sname   |
+-----+---------+
|   1 | suraj   |
|   3 | shubham |
|   4 | sanket  |
|   5 | abhi    |
+-----+---------+
4 rows in set (0.00 sec)

******************************** INSERTING KASHI RECORDS IN PLACE OF SURAJ RECORD *********************************************************
mysql> insert into student(sid,sname)values(2,'kashi');
Query OK, 1 row affected (0.14 sec)

mysql> select*from student;
+-----+---------+
| sid | sname   |
+-----+---------+
|   1 | suraj   |
|   2 | kashi   |
|   3 | shubham |
|   4 | sanket  |
|   5 | abhi    |
+-----+---------+
5 rows in set (0.00 sec)

mysql> insert into course(cid,cname)values(1,'Java'),(2,'Data'),(3,'C+');
Query OK, 3 rows affected (0.61 sec)
Records: 3  Duplicates: 0  Warnings: 0

mysql> select*from course;
+-----+-------+
| cid | cname |
+-----+-------+
|   1 | Java  |
|   2 | Data  |
|   3 | C+    |
+-----+-------+
3 rows in set (0.00 sec)

***************************************  INSERTING DATA OF MARKS TABLE ******************************************************************


mysql> insert into marks(studid,courseid,marks)values(1,'1',99),(1,'3',98),(2,'1',95),(2,'2',97);
Query OK, 4 rows affected (0.03 sec)
Records: 4  Duplicates: 0  Warnings: 0

mysql> select*from marks;
+--------+----------+-------+
| studid | courseid | marks |
+--------+----------+-------+
|      1 |        1 |    99 |
|      1 |        3 |    98 |
|      2 |        1 |    95 |
|      2 |        2 |    97 |
+--------+----------+-------+
4 rows in set (0.00 sec)




***************************************  Q 33 ************************************************


33. Create empty table emp10 with table structure same as emp table.
create table emp10 as
(
select *
from emp
where 1=2;
)

 Mgr int ,
hiredate date,' at line 1
mysql> create table empt(
    -> empno int primary key,
    -> Ename varchar(20)not null,
    -> Mgr int ,
    -> hiredate date,
    -> sal double (9,2) check(sal>0),
    -> comm int,
    -> deptno int);
Query OK, 0 rows affected, 1 warning (0.31 sec)

mysql> show table empt;
ERROR 1064 (42000): You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'empt' at line 1
mysql> select*from empt;
Empty set (0.00 sec)

mysql> select*
    -> from empt
    -> where 1=2;
Empty set (0.03 sec)

mysql> desc empt;
+----------+-------------+------+-----+---------+-------+
| Field    | Type        | Null | Key | Default | Extra |
+----------+-------------+------+-----+---------+-------+
| empno    | int         | NO   | PRI | NULL    |       |
| Ename    | varchar(20) | NO   |     | NULL    |       |
| Mgr      | int         | YES  |     | NULL    |       |
| hiredate | date        | YES  |     | NULL    |       |
| sal      | double(9,2) | YES  |     | NULL    |       |
| comm     | int         | YES  |     | NULL    |       |
| deptno   | int         | YES  |     | NULL    |       |
+----------+-------------+------+-----+---------+-------+
7 rows in set (0.00 sec)

mysql> (select*
    -> from empt
    -> where 1=2);
Empty set (0.00 sec)


***************************************  Q 34************************************************
 
********************************** DO BELOW STEP TO DO ROLLBACK IN FUTURE *************************************************************
          
                                      mysql> set autocommit=0;
			        Query OK, 0 rows affected (0.08 sec) 
*************************************************************************************************************************************** 
 
 
34. Solve following using alter table
add primary key constraint on emp,dept,salgrade
emp ----→ empno
dept---→ deptno
salgrade---→ grade
add foreign key constarint in emp
deptno --->> dept(deptno)
add new column in emp table netsal with constraint default 1000



mysql> alter  table salgrade
    -> modify grade int primary key;
Query OK, 0 rows affected (0.83 sec)
Records: 0  Duplicates: 0  Warnings: 0

mysql> alter table dept
    -> modify deptno int primary key;
Query OK, 0 rows affected (0.26 sec)
Records: 0  Duplicates: 0  Warnings: 0

mysql> alter  table emp
    -> modify empno int primary key;
Query OK, 0 rows affected (0.20 sec)
Records: 0  Duplicates: 0  Warnings: 0

mysql> alter  table emp
    -> add constraint fk_emp foreign key (deptno) references dept(deptno);
Query OK, 14 rows affected (0.31 sec)
Records: 14  Duplicates: 0  Warnings: 0

mysql> alter table emp
    -> add column netsal int default 1000;
Query OK, 0 rows affected (0.13 sec)
Records: 0  Duplicates: 0  Warnings: 0

mysql> desc emp;
+----------+--------------+------+-----+---------+-------+
| Field    | Type         | Null | Key | Default | Extra |
+----------+--------------+------+-----+---------+-------+
| empno    | int          | NO   | PRI | NULL    |       |
| ENAME    | varchar(10)  | YES  |     | NULL    |       |
| JOB      | varchar(9)   | YES  |     | NULL    |       |
| MGR      | int          | YES  |     | NULL    |       |
| HIREDATE | date         | YES  |     | NULL    |       |
| SAL      | decimal(7,2) | YES  |     | NULL    |       |
| COMM     | decimal(7,2) | YES  |     | NULL    |       |
| DEPTNO   | int          | YES  | MUL | NULL    |       |
| netsal   | int          | YES  |     | 1000    |       |
+----------+--------------+------+-----+---------+-------+
9 rows in set (0.00 sec)


***************************************  Q 35 ************************************************


35. Update employee sal ---- increase sal of each employee by 15 % sal +comm, change the job to
manager and mgr to 7777 for all employees in deptno 10.

********************************** increase sal of each employee by 15 % sal +comm ********************************************************

********************************** BEFORE CHANGING SALARY TABLE LOOKS LIKE BELOW **********************************************************


mysql> select*from emp;
+-------+--------+-----------+------+------------+---------+---------+--------+--------+
| empno | ENAME  | JOB       | MGR  | HIREDATE   | SAL     | COMM    | DEPTNO | netsal |
+-------+--------+-----------+------+------------+---------+---------+--------+--------+
|  7369 | SMITH  | CLERK     | 7902 | 1980-12-17 |  800.00 |    NULL |     20 |   1000 |
|  7499 | ALLEN  | SALESMAN  | 7698 | 1981-02-20 | 1600.00 |  300.00 |     30 |   1000 |
|  7521 | WARD   | SALESMAN  | 7698 | 1981-02-22 | 1250.00 |  500.00 |     30 |   1000 |
|  7566 | JONES  | MANAGER   | 7839 | 1981-04-02 | 2975.00 |    NULL |     20 |   1000 |
|  7654 | MARTIN | SALESMAN  | 7698 | 1981-09-28 | 1250.00 | 1400.00 |     30 |   1000 |
|  7698 | BLAKE  | MANAGER   | 7839 | 1981-05-01 | 2850.00 |    NULL |     30 |   1000 |
|  7782 | CLARK  | MANAGER   | 7839 | 1981-06-09 | 2450.00 |    NULL |     10 |   1000 |
|  7788 | SCOTT  | ANALYST   | 7566 | 1982-12-09 | 3000.00 |    NULL |     20 |   1000 |
|  7839 | KING   | PRESIDENT | NULL | 1981-11-17 | 5000.00 |    NULL |     10 |   1000 |
|  7844 | TURNER | SALESMAN  | 7698 | 1981-09-08 | 1500.00 |    0.00 |     30 |   1000 |
|  7876 | ADAMS  | CLERK     | 7788 | 1983-01-12 | 1100.00 |    NULL |     20 |   1000 |
|  7900 | JAMES  | CLERK     | 7698 | 1981-12-03 |  950.00 |    NULL |     30 |   1000 |
|  7902 | FORD   | ANALYST   | 7566 | 1981-12-03 | 3000.00 |    NULL |     20 |   1000 |
|  7934 | MILLER | CLERK     | 7782 | 1982-01-23 | 1300.00 |    NULL |     10 |   1000 |
+-------+--------+-----------+------+------------+---------+---------+--------+--------+
14 rows in set (0.00 sec)


********************************** AFTER CHANGING SALARY TABLE LOOKS LIKE BELOW ****************************************************************************


mysql> update emp
    -> set sal =sal*1.15+ifnull(comm,0);
Query OK, 14 rows affected (0.20 sec)
Rows matched: 14  Changed: 14  Warnings: 0


mysql> select * from emp;
+-------+--------+-----------+------+------------+---------+---------+--------+--------+
| empno | ENAME  | JOB       | MGR  | HIREDATE   | SAL     | COMM    | DEPTNO | netsal |
+-------+--------+-----------+------+------------+---------+---------+--------+--------+
|  7369 | SMITH  | CLERK     | 7902 | 1980-12-17 |  920.00 |    NULL |     20 |   1000 |
|  7499 | ALLEN  | SALESMAN  | 7698 | 1981-02-20 | 2140.00 |  300.00 |     30 |   1000 |
|  7521 | WARD   | SALESMAN  | 7698 | 1981-02-22 | 1937.50 |  500.00 |     30 |   1000 |
|  7566 | JONES  | MANAGER   | 7839 | 1981-04-02 | 3421.25 |    NULL |     20 |   1000 |
|  7654 | MARTIN | SALESMAN  | 7698 | 1981-09-28 | 2837.50 | 1400.00 |     30 |   1000 |
|  7698 | BLAKE  | MANAGER   | 7839 | 1981-05-01 | 3277.50 |    NULL |     30 |   1000 |
|  7782 | CLARK  | MANAGER   | 7839 | 1981-06-09 | 2817.50 |    NULL |     10 |   1000 |
|  7788 | SCOTT  | ANALYST   | 7566 | 1982-12-09 | 3450.00 |    NULL |     20 |   1000 |
|  7839 | KING   | PRESIDENT | NULL | 1981-11-17 | 5750.00 |    NULL |     10 |   1000 |
|  7844 | TURNER | SALESMAN  | 7698 | 1981-09-08 | 1725.00 |    0.00 |     30 |   1000 |
|  7876 | ADAMS  | CLERK     | 7788 | 1983-01-12 | 1265.00 |    NULL |     20 |   1000 |
|  7900 | JAMES  | CLERK     | 7698 | 1981-12-03 | 1092.50 |    NULL |     30 |   1000 |
|  7902 | FORD   | ANALYST   | 7566 | 1981-12-03 | 3450.00 |    NULL |     20 |   1000 |
|  7934 | MILLER | CLERK     | 7782 | 1982-01-23 | 1495.00 |    NULL |     10 |   1000 |
+-------+--------+-----------+------+------------+---------+---------+--------+--------+
14 rows in set (0.00 sec)


************************************************* change the job to manager ************************************************************

mysql> UPDATE EMP
    -> SET JOB='Manager'
    -> where deptno=10;
Query OK, 3 rows affected (0.31 sec)
Rows matched: 3  Changed: 3  Warnings: 0

mysql> select * from emp;
+-------+--------+----------+------+------------+---------+---------+--------+--------+
| empno | ENAME  | JOB      | MGR  | HIREDATE   | SAL     | COMM    | DEPTNO | netsal |
+-------+--------+----------+------+------------+---------+---------+--------+--------+
|  7369 | SMITH  | CLERK    | 7902 | 1980-12-17 |  920.00 |    NULL |     20 |   1000 |
|  7499 | ALLEN  | SALESMAN | 7698 | 1981-02-20 | 2140.00 |  300.00 |     30 |   1000 |
|  7521 | WARD   | SALESMAN | 7698 | 1981-02-22 | 1937.50 |  500.00 |     30 |   1000 |
|  7566 | JONES  | MANAGER  | 7839 | 1981-04-02 | 3421.25 |    NULL |     20 |   1000 |
|  7654 | MARTIN | SALESMAN | 7698 | 1981-09-28 | 2837.50 | 1400.00 |     30 |   1000 |
|  7698 | BLAKE  | MANAGER  | 7839 | 1981-05-01 | 3277.50 |    NULL |     30 |   1000 |
|  7782 | CLARK  | Manager  | 7839 | 1981-06-09 | 2817.50 |    NULL |     10 |   1000 |
|  7788 | SCOTT  | ANALYST  | 7566 | 1982-12-09 | 3450.00 |    NULL |     20 |   1000 |
|  7839 | KING   | Manager  | NULL | 1981-11-17 | 5750.00 |    NULL |     10 |   1000 |
|  7844 | TURNER | SALESMAN | 7698 | 1981-09-08 | 1725.00 |    0.00 |     30 |   1000 |
|  7876 | ADAMS  | CLERK    | 7788 | 1983-01-12 | 1265.00 |    NULL |     20 |   1000 |
|  7900 | JAMES  | CLERK    | 7698 | 1981-12-03 | 1092.50 |    NULL |     30 |   1000 |
|  7902 | FORD   | ANALYST  | 7566 | 1981-12-03 | 3450.00 |    NULL |     20 |   1000 |
|  7934 | MILLER | Manager  | 7782 | 1982-01-23 | 1495.00 |    NULL |     10 |   1000 |
+-------+--------+----------+------+------------+---------+---------+--------+--------+
14 rows in set (0.00 sec)


*************************************** mgr to 7777 for all employees in deptno 10 ***************************************************

mysql> update emp
    -> set mgr=7777
    -> where job='manager';
Query OK, 5 rows affected (0.43 sec)
Rows matched: 5  Changed: 5  Warnings: 0

mysql> select * from emp;
+-------+--------+----------+------+------------+---------+---------+--------+--------+
| empno | ENAME  | JOB      | MGR  | HIREDATE   | SAL     | COMM    | DEPTNO | netsal |
+-------+--------+----------+------+------------+---------+---------+--------+--------+
|  7369 | SMITH  | CLERK    | 7902 | 1980-12-17 |  920.00 |    NULL |     20 |   1000 |
|  7499 | ALLEN  | SALESMAN | 7698 | 1981-02-20 | 2140.00 |  300.00 |     30 |   1000 |
|  7521 | WARD   | SALESMAN | 7698 | 1981-02-22 | 1937.50 |  500.00 |     30 |   1000 |
|  7566 | JONES  | MANAGER  | 7777 | 1981-04-02 | 3421.25 |    NULL |     20 |   1000 |
|  7654 | MARTIN | SALESMAN | 7698 | 1981-09-28 | 2837.50 | 1400.00 |     30 |   1000 |
|  7698 | BLAKE  | MANAGER  | 7777 | 1981-05-01 | 3277.50 |    NULL |     30 |   1000 |
|  7782 | CLARK  | Manager  | 7777 | 1981-06-09 | 2817.50 |    NULL |     10 |   1000 |
|  7788 | SCOTT  | ANALYST  | 7566 | 1982-12-09 | 3450.00 |    NULL |     20 |   1000 |
|  7839 | KING   | Manager  | 7777 | 1981-11-17 | 5750.00 |    NULL |     10 |   1000 |
|  7844 | TURNER | SALESMAN | 7698 | 1981-09-08 | 1725.00 |    0.00 |     30 |   1000 |
|  7876 | ADAMS  | CLERK    | 7788 | 1983-01-12 | 1265.00 |    NULL |     20 |   1000 |
|  7900 | JAMES  | CLERK    | 7698 | 1981-12-03 | 1092.50 |    NULL |     30 |   1000 |
|  7902 | FORD   | ANALYST  | 7566 | 1981-12-03 | 3450.00 |    NULL |     20 |   1000 |
|  7934 | MILLER | Manager  | 7777 | 1982-01-23 | 1495.00 |    NULL |     10 |   1000 |
+-------+--------+----------+------+------------+---------+---------+--------+--------+
14 rows in set (0.00 sec)


******************************************************* End of Question 35 **************************************************************



******************************************************* Question 36 **************************************************************

  36. change job of smith to senior clerk 


mysql> update emp
    -> set job='sclerk'
    -> where ename='smith';
Query OK, 1 row affected (0.11 sec)
Rows matched: 1  Changed: 1  Warnings: 0

mysql> select*from emp;
+-------+--------+----------+------+------------+---------+---------+--------+--------+
| empno | ENAME  | JOB      | MGR  | HIREDATE   | SAL     | COMM    | DEPTNO | netsal |
+-------+--------+----------+------+------------+---------+---------+--------+--------+
|  7369 | SMITH  | sclerk   | 7902 | 1980-12-17 |  920.00 |    NULL |     20 |   1000 |
|  7499 | ALLEN  | SALESMAN | 7698 | 1981-02-20 | 2140.00 |  300.00 |     30 |   1000 |
|  7521 | WARD   | SALESMAN | 7698 | 1981-02-22 | 1937.50 |  500.00 |     30 |   1000 |
|  7566 | JONES  | MANAGER  | 7777 | 1981-04-02 | 3421.25 |    NULL |     20 |   1000 |
|  7654 | MARTIN | SALESMAN | 7698 | 1981-09-28 | 2837.50 | 1400.00 |     30 |   1000 |
|  7698 | BLAKE  | MANAGER  | 7777 | 1981-05-01 | 3277.50 |    NULL |     30 |   1000 |
|  7782 | CLARK  | Manager  | 7777 | 1981-06-09 | 2817.50 |    NULL |     10 |   1000 |
|  7788 | SCOTT  | ANALYST  | 7566 | 1982-12-09 | 3450.00 |    NULL |     20 |   1000 |
|  7839 | KING   | Manager  | 7777 | 1981-11-17 | 5750.00 |    NULL |     10 |   1000 |
|  7844 | TURNER | SALESMAN | 7698 | 1981-09-08 | 1725.00 |    0.00 |     30 |   1000 |
|  7876 | ADAMS  | CLERK    | 7788 | 1983-01-12 | 1265.00 |    NULL |     20 |   1000 |
|  7900 | JAMES  | CLERK    | 7698 | 1981-12-03 | 1092.50 |    NULL |     30 |   1000 |
|  7902 | FORD   | ANALYST  | 7566 | 1981-12-03 | 3450.00 |    NULL |     20 |   1000 |
|  7934 | MILLER | Manager  | 7777 | 1982-01-23 | 1495.00 |    NULL |     10 |   1000 |
+-------+--------+----------+------+------------+---------+---------+--------+--------+
14 rows in set (0.00 sec)



******************************************************* Question 37 **************************************************************

 37.increase salary of all employees by 15% if they are earning some commission
 
 ********************************** BEFORE CHANGING SALARY TABLE LOOKS LIKE BELOW ****************************************************************************
 
 
 
 mysql> select*from emp;
+-------+--------+----------+------+------------+---------+---------+--------+--------+
| empno | ENAME  | JOB      | MGR  | HIREDATE   | SAL     | COMM    | DEPTNO | netsal |
+-------+--------+----------+------+------------+---------+---------+--------+--------+
|  7369 | SMITH  | sclerk   | 7902 | 1980-12-17 |  920.00 |    NULL |     20 |   1000 |
|  7499 | ALLEN  | SALESMAN | 7698 | 1981-02-20 | 2140.00 |  300.00 |     30 |   1000 |
|  7521 | WARD   | SALESMAN | 7698 | 1981-02-22 | 1937.50 |  500.00 |     30 |   1000 |
|  7566 | JONES  | MANAGER  | 7777 | 1981-04-02 | 3421.25 |    NULL |     20 |   1000 |
|  7654 | MARTIN | SALESMAN | 7698 | 1981-09-28 | 2837.50 | 1400.00 |     30 |   1000 |
|  7698 | BLAKE  | MANAGER  | 7777 | 1981-05-01 | 3277.50 |    NULL |     30 |   1000 |
|  7782 | CLARK  | Manager  | 7777 | 1981-06-09 | 2817.50 |    NULL |     10 |   1000 |
|  7788 | SCOTT  | ANALYST  | 7566 | 1982-12-09 | 3450.00 |    NULL |     20 |   1000 |
|  7839 | KING   | Manager  | 7777 | 1981-11-17 | 5750.00 |    NULL |     10 |   1000 |
|  7844 | TURNER | SALESMAN | 7698 | 1981-09-08 | 1725.00 |    0.00 |     30 |   1000 |
|  7876 | ADAMS  | CLERK    | 7788 | 1983-01-12 | 1265.00 |    NULL |     20 |   1000 |
|  7900 | JAMES  | CLERK    | 7698 | 1981-12-03 | 1092.50 |    NULL |     30 |   1000 |
|  7902 | FORD   | ANALYST  | 7566 | 1981-12-03 | 3450.00 |    NULL |     20 |   1000 |
|  7934 | MILLER | Manager  | 7777 | 1982-01-23 | 1495.00 |    NULL |     10 |   1000 |
+-------+--------+----------+------+------------+---------+---------+--------+--------+
14 rows in set (0.00 sec)

********************************** AFTER CHANGING SALARY TABLE LOOKS LIKE BELOW ****************************************************************************

mysql> update emp
    -> set sal=sal*1.15
    -> where comm is not null;
Query OK, 4 rows affected, 2 warnings (0.03 sec)
Rows matched: 4  Changed: 4  Warnings: 2


mysql> select*from emp;
+-------+--------+----------+------+------------+---------+---------+--------+--------+
| empno | ENAME  | JOB      | MGR  | HIREDATE   | SAL     | COMM    | DEPTNO | netsal |
+-------+--------+----------+------+------------+---------+---------+--------+--------+
|  7369 | SMITH  | sclerk   | 7902 | 1980-12-17 |  920.00 |    NULL |     20 |   1000 |
|  7499 | ALLEN  | SALESMAN | 7698 | 1981-02-20 | 2461.00 |  300.00 |     30 |   1000 |
|  7521 | WARD   | SALESMAN | 7698 | 1981-02-22 | 2228.13 |  500.00 |     30 |   1000 |
|  7566 | JONES  | MANAGER  | 7777 | 1981-04-02 | 3421.25 |    NULL |     20 |   1000 |
|  7654 | MARTIN | SALESMAN | 7698 | 1981-09-28 | 3263.13 | 1400.00 |     30 |   1000 |
|  7698 | BLAKE  | MANAGER  | 7777 | 1981-05-01 | 3277.50 |    NULL |     30 |   1000 |
|  7782 | CLARK  | Manager  | 7777 | 1981-06-09 | 2817.50 |    NULL |     10 |   1000 |
|  7788 | SCOTT  | ANALYST  | 7566 | 1982-12-09 | 3450.00 |    NULL |     20 |   1000 |
|  7839 | KING   | Manager  | 7777 | 1981-11-17 | 5750.00 |    NULL |     10 |   1000 |
|  7844 | TURNER | SALESMAN | 7698 | 1981-09-08 | 1983.75 |    0.00 |     30 |   1000 |
|  7876 | ADAMS  | CLERK    | 7788 | 1983-01-12 | 1265.00 |    NULL |     20 |   1000 |
|  7900 | JAMES  | CLERK    | 7698 | 1981-12-03 | 1092.50 |    NULL |     30 |   1000 |
|  7902 | FORD   | ANALYST  | 7566 | 1981-12-03 | 3450.00 |    NULL |     20 |   1000 |
|  7934 | MILLER | Manager  | 7777 | 1982-01-23 | 1495.00 |    NULL |     10 |   1000 |
+-------+--------+----------+------+------------+---------+---------+--------+--------+
14 rows in set (0.00 sec)


******************************************************* Question 38 **************************************************************

38. list all employees with sal>smith's sal

mysql> select* from emp
    -> where sal>(select sal
    -> from emp
    -> where ename='smith');
+-------+--------+----------+------+------------+---------+---------+--------+--------+
| empno | ENAME  | JOB      | MGR  | HIREDATE   | SAL     | COMM    | DEPTNO | netsal |
+-------+--------+----------+------+------------+---------+---------+--------+--------+
|  7499 | ALLEN  | SALESMAN | 7698 | 1981-02-20 | 2461.00 |  300.00 |     30 |   1000 |
|  7521 | WARD   | SALESMAN | 7698 | 1981-02-22 | 2228.13 |  500.00 |     30 |   1000 |
|  7566 | JONES  | MANAGER  | 7777 | 1981-04-02 | 3421.25 |    NULL |     20 |   1000 |
|  7654 | MARTIN | SALESMAN | 7698 | 1981-09-28 | 3263.13 | 1400.00 |     30 |   1000 |
|  7698 | BLAKE  | MANAGER  | 7777 | 1981-05-01 | 3277.50 |    NULL |     30 |   1000 |
|  7782 | CLARK  | Manager  | 7777 | 1981-06-09 | 2817.50 |    NULL |     10 |   1000 |
|  7788 | SCOTT  | ANALYST  | 7566 | 1982-12-09 | 3450.00 |    NULL |     20 |   1000 |
|  7839 | KING   | Manager  | 7777 | 1981-11-17 | 5750.00 |    NULL |     10 |   1000 |
|  7844 | TURNER | SALESMAN | 7698 | 1981-09-08 | 1983.75 |    0.00 |     30 |   1000 |
|  7876 | ADAMS  | CLERK    | 7788 | 1983-01-12 | 1265.00 |    NULL |     20 |   1000 |
|  7900 | JAMES  | CLERK    | 7698 | 1981-12-03 | 1092.50 |    NULL |     30 |   1000 |
|  7902 | FORD   | ANALYST  | 7566 | 1981-12-03 | 3450.00 |    NULL |     20 |   1000 |
|  7934 | MILLER | Manager  | 7777 | 1982-01-23 | 1495.00 |    NULL |     10 |   1000 |
+-------+--------+----------+------+------------+---------+---------+--------+--------+
13 rows in set (0.00 sec)

****************************************** cheking for clark (vadhiv kam)*************************************************************************


mysql> select* from emp
    -> where sal>(select sal
    -> from emp
    -> where ename='clark');
+-------+--------+----------+------+------------+---------+---------+--------+--------+
| empno | ENAME  | JOB      | MGR  | HIREDATE   | SAL     | COMM    | DEPTNO | netsal |
+-------+--------+----------+------+------------+---------+---------+--------+--------+
|  7566 | JONES  | MANAGER  | 7777 | 1981-04-02 | 3421.25 |    NULL |     20 |   1000 |
|  7654 | MARTIN | SALESMAN | 7698 | 1981-09-28 | 3263.13 | 1400.00 |     30 |   1000 |
|  7698 | BLAKE  | MANAGER  | 7777 | 1981-05-01 | 3277.50 |    NULL |     30 |   1000 |
|  7788 | SCOTT  | ANALYST  | 7566 | 1982-12-09 | 3450.00 |    NULL |     20 |   1000 |
|  7839 | KING   | Manager  | 7777 | 1981-11-17 | 5750.00 |    NULL |     10 |   1000 |
|  7902 | FORD   | ANALYST  | 7566 | 1981-12-03 | 3450.00 |    NULL |     20 |   1000 |
+-------+--------+----------+------+------------+---------+---------+--------+--------+
6 rows in set (0.00 sec)


******************************************************* Question 39 **************************************************************

39. list all employees who are working in smith's department

mysql> select* from emp
    -> where deptno=(select deptno
    -> from emp
    -> where ename='smith');
+-------+-------+---------+------+------------+---------+------+--------+--------+
| empno | ENAME | JOB     | MGR  | HIREDATE   | SAL     | COMM | DEPTNO | netsal |
+-------+-------+---------+------+------------+---------+------+--------+--------+
|  7369 | SMITH | sclerk  | 7902 | 1980-12-17 |  920.00 | NULL |     20 |   1000 |
|  7566 | JONES | MANAGER | 7777 | 1981-04-02 | 3421.25 | NULL |     20 |   1000 |
|  7788 | SCOTT | ANALYST | 7566 | 1982-12-09 | 3450.00 | NULL |     20 |   1000 |
|  7876 | ADAMS | CLERK   | 7788 | 1983-01-12 | 1265.00 | NULL |     20 |   1000 |
|  7902 | FORD  | ANALYST | 7566 | 1981-12-03 | 3450.00 | NULL |     20 |   1000 |
+-------+-------+---------+------+------------+---------+------+--------+--------+
5 rows in set (0.00 sec)


******************************************************* Question 40 **************************************************************

40. list all employees with sal < miller's sal and salary > miller's sal

****************question is modified **********************************************************************************************

mysql> select *
    -> from emp
    -> where sal<(select sal
    -> from emp
    -> where ename='blake')and sal>(select sal
    -> from emp
    -> where ename='miller');
+-------+--------+----------+------+------------+---------+---------+--------+--------+
| empno | ENAME  | JOB      | MGR  | HIREDATE   | SAL     | COMM    | DEPTNO | netsal |
+-------+--------+----------+------+------------+---------+---------+--------+--------+
|  7499 | ALLEN  | SALESMAN | 7698 | 1981-02-20 | 2461.00 |  300.00 |     30 |   1000 |
|  7521 | WARD   | SALESMAN | 7698 | 1981-02-22 | 2228.13 |  500.00 |     30 |   1000 |
|  7654 | MARTIN | SALESMAN | 7698 | 1981-09-28 | 3263.13 | 1400.00 |     30 |   1000 |
|  7782 | CLARK  | Manager  | 7777 | 1981-06-09 | 2817.50 |    NULL |     10 |   1000 |
|  7844 | TURNER | SALESMAN | 7698 | 1981-09-08 | 1983.75 |    0.00 |     30 |   1000 |
+-------+--------+----------+------+------------+---------+---------+--------+--------+
5 rows in set (0.00 sec)

******************************************************* Question 41 **************************************************************

41. delete all employees working in alan's department


********************************** BEFORE CHANGING TABLE LOOKS LIKE BELOW *********************************************************************


mysql> select *from emp;
+-------+--------+-----------+------+------------+---------+---------+--------+
| EMPNO | ENAME  | JOB       | MGR  | HIREDATE   | SAL     | COMM    | DEPTNO |
+-------+--------+-----------+------+------------+---------+---------+--------+
|  7369 | SMITH  | CLERK     | 7902 | 1980-12-17 |  800.00 |    NULL |     20 |
|  7499 | ALLEN  | SALESMAN  | 7698 | 1981-02-20 | 1600.00 |  300.00 |     30 |
|  7521 | WARD   | SALESMAN  | 7698 | 1981-02-22 | 1250.00 |  500.00 |     30 |
|  7566 | JONES  | MANAGER   | 7839 | 1981-04-02 | 2975.00 |    NULL |     20 |
|  7654 | MARTIN | SALESMAN  | 7698 | 1981-09-28 | 1250.00 | 1400.00 |     30 |
|  7698 | BLAKE  | MANAGER   | 7839 | 1981-05-01 | 2850.00 |    NULL |     30 |
|  7782 | CLARK  | MANAGER   | 7839 | 1981-06-09 | 2450.00 |    NULL |     10 |
|  7788 | SCOTT  | ANALYST   | 7566 | 1982-12-09 | 3000.00 |    NULL |     20 |
|  7839 | KING   | PRESIDENT | NULL | 1981-11-17 | 5000.00 |    NULL |     10 |
|  7844 | TURNER | SALESMAN  | 7698 | 1981-09-08 | 1500.00 |    0.00 |     30 |
|  7876 | ADAMS  | CLERK     | 7788 | 1983-01-12 | 1100.00 |    NULL |     20 |
|  7900 | JAMES  | CLERK     | 7698 | 1981-12-03 |  950.00 |    NULL |     30 |
|  7902 | FORD   | ANALYST   | 7566 | 1981-12-03 | 3000.00 |    NULL |     20 |
|  7934 | MILLER | CLERK     | 7782 | 1982-01-23 | 1300.00 |    NULL |     10 |
+-------+--------+-----------+------+------------+---------+---------+--------+
14 rows in set (0.00 sec)

********************************** AFTER CHANGING TABLE LOOKS LIKE BELOW *********************************************************************

mysql> delete from emp
    -> where deptno=(select deptno
    -> from (select*from emp) e
    -> where ename='allen');
Query OK, 6 rows affected (0.14 sec)


mysql> select*from emp;
+-------+--------+---------+------+------------+---------+------+--------+--------+
| empno | ENAME  | JOB     | MGR  | HIREDATE   | SAL     | COMM | DEPTNO | netsal |
+-------+--------+---------+------+------------+---------+------+--------+--------+
|  7369 | SMITH  | sclerk  | 7902 | 1980-12-17 |  920.00 | NULL |     20 |   1000 |
|  7566 | JONES  | MANAGER | 7777 | 1981-04-02 | 3421.25 | NULL |     20 |   1000 |
|  7782 | CLARK  | Manager | 7777 | 1981-06-09 | 2817.50 | NULL |     10 |   1000 |
|  7788 | SCOTT  | ANALYST | 7566 | 1982-12-09 | 3450.00 | NULL |     20 |   1000 |
|  7839 | KING   | Manager | 7777 | 1981-11-17 | 5750.00 | NULL |     10 |   1000 |
|  7876 | ADAMS  | CLERK   | 7788 | 1983-01-12 | 1265.00 | NULL |     20 |   1000 |
|  7902 | FORD   | ANALYST | 7566 | 1981-12-03 | 3450.00 | NULL |     20 |   1000 |
|  7934 | MILLER | Manager | 7777 | 1982-01-23 | 1495.00 | NULL |     10 |   1000 |
+-------+--------+---------+------+------------+---------+------+--------+--------+
8 rows in set (0.00 sec)4

******************************************************* Question 42 **************************************************************

42. change salary of Alan to the salary of Miller.

mysql> update emp
    -> set sal=(select sal
    -> from (select *from emp)e
    -> where ename='allen')
    -> where ename='miller';
Query OK, 1 row affected (0.00 sec)
Rows matched: 1  Changed: 1  Warnings: 0

***************** In this table before changing salary of miller is 1300 and after changing the salary becomes 1600 i.e salary of allen********* 

mysql> select*from emp;
+-------+--------+-----------+------+------------+---------+---------+--------+
| empno | ENAME  | JOB       | MGR  | HIREDATE   | SAL     | COMM    | DEPTNO |
+-------+--------+-----------+------+------------+---------+---------+--------+
|  7369 | SMITH  | CLERK     | 7902 | 1980-12-17 |  800.00 |    NULL |     20 |
|  7499 | ALLEN  | SALESMAN  | 7698 | 1981-02-20 | 1600.00 |  300.00 |     30 |
|  7521 | WARD   | SALESMAN  | 7698 | 1981-02-22 | 1250.00 |  500.00 |     30 |
|  7566 | JONES  | MANAGER   | 7839 | 1981-04-02 | 2975.00 |    NULL |     20 |
|  7654 | MARTIN | SALESMAN  | 7698 | 1981-09-28 | 1250.00 | 1400.00 |     30 |
|  7698 | BLAKE  | MANAGER   | 7839 | 1981-05-01 | 2850.00 |    NULL |     30 |
|  7782 | CLARK  | MANAGER   | 7839 | 1981-06-09 | 2450.00 |    NULL |     10 |
|  7788 | SCOTT  | ANALYST   | 7566 | 1982-12-09 | 3000.00 |    NULL |     20 |
|  7839 | KING   | PRESIDENT | NULL | 1981-11-17 | 5000.00 |    NULL |     10 |
|  7844 | TURNER | SALESMAN  | 7698 | 1981-09-08 | 1500.00 |    0.00 |     30 |
|  7876 | ADAMS  | CLERK     | 7788 | 1983-01-12 | 1100.00 |    NULL |     20 |
|  7900 | JAMES  | CLERK     | 7698 | 1981-12-03 |  950.00 |    NULL |     30 |
|  7902 | FORD   | ANALYST   | 7566 | 1981-12-03 | 3000.00 |    NULL |     20 |
|  7934 | MILLER | CLERK     | 7782 | 1982-01-23 | 1600.00 |    NULL |     10 |
+-------+--------+-----------+------+------------+---------+---------+--------+
14 rows in set (0.00 sec)




******************************************************* Question 43 **************************************************************


mysql> update emp
    -> set sal=(select sal
    -> from(select*from emp)e
    -> where ename='miller')
    -> where deptno=(select deptno
    -> from(select*from emp)m
    -> where ename='smith');
Query OK, 5 rows affected (0.00 sec)
Rows matched: 5  Changed: 5  Warnings: 0

mysql> select*from emp;
+-------+--------+-----------+------+------------+---------+---------+--------+
| empno | ENAME  | JOB       | MGR  | HIREDATE   | SAL     | COMM    | DEPTNO |
+-------+--------+-----------+------+------------+---------+---------+--------+
|  7369 | SMITH  | CLERK     | 7902 | 1980-12-17 | 1600.00 |    NULL |     20 |
|  7499 | ALLEN  | SALESMAN  | 7698 | 1981-02-20 | 1600.00 |  300.00 |     30 |
|  7521 | WARD   | SALESMAN  | 7698 | 1981-02-22 | 1250.00 |  500.00 |     30 |
|  7566 | JONES  | MANAGER   | 7839 | 1981-04-02 | 1600.00 |    NULL |     20 |
|  7654 | MARTIN | SALESMAN  | 7698 | 1981-09-28 | 1250.00 | 1400.00 |     30 |
|  7698 | BLAKE  | MANAGER   | 7839 | 1981-05-01 | 2850.00 |    NULL |     30 |
|  7782 | CLARK  | MANAGER   | 7839 | 1981-06-09 | 2450.00 |    NULL |     10 |
|  7788 | SCOTT  | ANALYST   | 7566 | 1982-12-09 | 1600.00 |    NULL |     20 |
|  7839 | KING   | PRESIDENT | NULL | 1981-11-17 | 5000.00 |    NULL |     10 |
|  7844 | TURNER | SALESMAN  | 7698 | 1981-09-08 | 1500.00 |    0.00 |     30 |
|  7876 | ADAMS  | CLERK     | 7788 | 1983-01-12 | 1600.00 |    NULL |     20 |
|  7900 | JAMES  | CLERK     | 7698 | 1981-12-03 |  950.00 |    NULL |     30 |
|  7902 | FORD   | ANALYST   | 7566 | 1981-12-03 | 1600.00 |    NULL |     20 |
|  7934 | MILLER | CLERK     | 7782 | 1982-01-23 | 1600.00 |    NULL |     10 |
+-------+--------+-----------+------+------------+---------+---------+--------+
14 rows in set (0.00 sec)


****************************************************** Question 44 **************************************************************


44. list all employees with salary > either Smith's salary or alan's sal

mysql> select*
    -> from emp
    -> where sal>(select sal from emp where ename='smith')or (select sal from emp where ename='allen');
	
	
+-------+--------+-----------+------+------------+---------+---------+--------+
| empno | ENAME  | JOB       | MGR  | HIREDATE   | SAL     | COMM    | DEPTNO |
+-------+--------+-----------+------+------------+---------+---------+--------+
|  7369 | SMITH  | CLERK     | 7902 | 1980-12-17 | 1600.00 |    NULL |     20 |
|  7499 | ALLEN  | SALESMAN  | 7698 | 1981-02-20 | 1600.00 |  300.00 |     30 |
|  7521 | WARD   | SALESMAN  | 7698 | 1981-02-22 | 1250.00 |  500.00 |     30 |
|  7566 | JONES  | MANAGER   | 7839 | 1981-04-02 | 1600.00 |    NULL |     20 |
|  7654 | MARTIN | SALESMAN  | 7698 | 1981-09-28 | 1250.00 | 1400.00 |     30 |
|  7698 | BLAKE  | MANAGER   | 7839 | 1981-05-01 | 2850.00 |    NULL |     30 |
|  7782 | CLARK  | MANAGER   | 7839 | 1981-06-09 | 2450.00 |    NULL |     10 |
|  7788 | SCOTT  | ANALYST   | 7566 | 1982-12-09 | 1600.00 |    NULL |     20 |
|  7839 | KING   | PRESIDENT | NULL | 1981-11-17 | 5000.00 |    NULL |     10 |
|  7844 | TURNER | SALESMAN  | 7698 | 1981-09-08 | 1500.00 |    0.00 |     30 |
|  7876 | ADAMS  | CLERK     | 7788 | 1983-01-12 | 1600.00 |    NULL |     20 |
|  7900 | JAMES  | CLERK     | 7698 | 1981-12-03 |  950.00 |    NULL |     30 |
|  7902 | FORD   | ANALYST   | 7566 | 1981-12-03 | 1600.00 |    NULL |     20 |
|  7934 | MILLER | CLERK     | 7782 | 1982-01-23 | 1600.00 |    NULL |     10 |
+-------+--------+-----------+------+------------+---------+---------+--------+
14 rows in set (0.00 sec)

****************************************************** Question 45 **************************************************************

45. list all employees who earn more than average sal of dept 10

mysql> select*
    -> from emp
    -> where sal>(select avg(sal) from emp where deptno=10);
+-------+-------+-----------+------+------------+---------+------+--------+
| empno | ENAME | JOB       | MGR  | HIREDATE   | SAL     | COMM | DEPTNO |
+-------+-------+-----------+------+------------+---------+------+--------+
|  7839 | KING  | PRESIDENT | NULL | 1981-11-17 | 5000.00 | NULL |     10 |
+-------+-------+-----------+------+------------+---------+------+--------+
1 row in set (0.00 sec)



****************************************************** Question 46**************************************************************

46. list all employees who earn more than average sal of Alan's department


mysql> select*
    -> from emp
    -> where sal>(select avg(sal) from emp where deptno=(select deptno from emp where ename='allen'));
+-------+--------+-----------+------+------------+---------+--------+--------+
| empno | ENAME  | JOB       | MGR  | HIREDATE   | SAL     | COMM   | DEPTNO |
+-------+--------+-----------+------+------------+---------+--------+--------+
|  7369 | SMITH  | CLERK     | 7902 | 1980-12-17 | 1600.00 |   NULL |     20 |
|  7499 | ALLEN  | SALESMAN  | 7698 | 1981-02-20 | 1600.00 | 300.00 |     30 |
|  7566 | JONES  | MANAGER   | 7839 | 1981-04-02 | 1600.00 |   NULL |     20 |
|  7698 | BLAKE  | MANAGER   | 7839 | 1981-05-01 | 2850.00 |   NULL |     30 |
|  7782 | CLARK  | MANAGER   | 7839 | 1981-06-09 | 2450.00 |   NULL |     10 |
|  7788 | SCOTT  | ANALYST   | 7566 | 1982-12-09 | 1600.00 |   NULL |     20 |
|  7839 | KING   | PRESIDENT | NULL | 1981-11-17 | 5000.00 |   NULL |     10 |
|  7876 | ADAMS  | CLERK     | 7788 | 1983-01-12 | 1600.00 |   NULL |     20 |
|  7902 | FORD   | ANALYST   | 7566 | 1981-12-03 | 1600.00 |   NULL |     20 |
|  7934 | MILLER | CLERK     | 7782 | 1982-01-23 | 1600.00 |   NULL |     10 |
+-------+--------+-----------+------+------------+---------+--------+--------+
10 rows in set (0.00 sec)


****************************************************** Question 47**************************************************************

47. list all employees who are working in purchase department(  use Accounting departement instead of purchase dept as it is not present in the dept table)

mysql> select*
    -> from emp
    -> where deptno=(select deptno from dept where dname='accounting');
+-------+--------+-----------+------+------------+---------+------+--------+
| empno | ENAME  | JOB       | MGR  | HIREDATE   | SAL     | COMM | DEPTNO |
+-------+--------+-----------+------+------------+---------+------+--------+
|  7782 | CLARK  | MANAGER   | 7839 | 1981-06-09 | 2450.00 | NULL |     10 |
|  7839 | KING   | PRESIDENT | NULL | 1981-11-17 | 5000.00 | NULL |     10 |
|  7934 | MILLER | CLERK     | 7782 | 1982-01-23 | 1600.00 | NULL |     10 |
+-------+--------+-----------+------+------------+---------+------+--------+
3 rows in set (0.00 sec)

****************************************************** Question 48**************************************************************
48. list all employees who earn more than average salary of their own department