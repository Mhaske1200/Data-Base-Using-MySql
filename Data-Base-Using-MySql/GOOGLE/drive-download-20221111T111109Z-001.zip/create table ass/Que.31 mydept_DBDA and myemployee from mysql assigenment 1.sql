﻿31. Practice creating following tables
create table mydept_DBDA
(
deptid number primary key,
dname varchar2(20) not null unique,
dloc varchar2(20)
)
insert into mydept_DBDA values(30,'Purchase','Mumbai');
create table myemployee
(
empno number(5) primary key,
fname varchar2(15) not null,
mname varchar2(15),
lname varchar2(15) not null,
sal number(9,2) check(sal >=1000),
doj date default sysdate,
passportnum varchar2(15) unique,
deptno number constraint fk_deptno references mydept_DBDA(deptid) on delete
cascade
)

******************************************* SOLUTION *******************************************************************
mysql> create table mydept_DBDA(
    -> deptid int primary key,
    -> dname varchar(20) not null unique,
    -> dloc varchar(20)
    -> );
Query OK, 0 rows affected (0.26 sec)

mysql> desc mydept_DBDA;
+--------+-------------+------+-----+---------+-------+
| Field  | Type        | Null | Key | Default | Extra |
+--------+-------------+------+-----+---------+-------+
| deptid | int         | NO   | PRI | NULL    |       |
| dname  | varchar(20) | NO   | UNI | NULL    |       |
| dloc   | varchar(20) | YES  |     | NULL    |       |
+--------+-------------+------+-----+---------+-------+
3 rows in set (0.00 sec)

mysql> insert into mydept_DBDA values(30,'Purchase','Mumbai');
Query OK, 1 row affected (0.14 sec)




******************* CREATING MY EMPLOYEE TABLE AND INSERING VALUES*****************************************************

mysql> create table myemployee(
    -> empno int primary key,
    -> fname varchar(15) not null,
    -> mname varchar(15),
    -> lname varchar(15) not null,
    -> sal int check(sal>=1000),
    -> doj datetime,
    -> deptno int ,
    -> passportnum varchar(15) unique,
    -> constraint fk_deptno foreign key(deptno) references mydept_DBDA(deptid));
Query OK, 0 rows affected (0.17 sec)

mysql> insert into myemployee(empno , fname , mname , lname , sal , doj , deptno , passportnum) values
    -> (2369 , 'Shubham' , 'Ganesh' , 'Mhaske' , 5000 , '2022-09-15' , 30 , "ASH545835AS ");
Query OK, 1 row affected (0.68 sec)


****************** inserting more deptid because it is creating problem because of contraints we created in myepmloee table(child) and if other number is inserted than deptid ****************************

mysql> insert into mydept_DBDA (deptid , dname , dloc) values (50 , 'Structure' , 'Delhi'),(15 , 'Fluid Mechanics' , 'Lucknow');
Query OK, 2 rows affected (0.55 sec)
Records: 2  Duplicates: 0  Warnings: 0

mysql> select * from mydept_dbda;
+--------+-----------------+---------+
| deptid | dname           | dloc    |
+--------+-----------------+---------+
|     15 | Fluid Mechanics | Lucknow |
|     30 | Purchase        | Mumbai  |
|     50 | Structure       | Delhi   |
+--------+-----------------+---------+
3 rows in set (0.00 sec)

************************ ADDING TWO MORE RECORS IN TABLE MYEPLOYEE**********************************

mysql> insert into myemployee(empno , fname , mname , lname , sal , doj , deptno , passportnum) values
    -> (2367 , 'Shubham' ,'', 'Ahire' , 50000 , '2022-01-15' , 50 , "ASH5555835AS "),
    -> (2368 , 'Suraj' ,'', 'Chechare' , 90000 , '2022-01-25' , 15 , "ASH555666835AS ");
Query OK, 2 rows affected (0.04 sec)
Records: 2  Duplicates: 0  Warnings: 0

************************ PRINTING CREATED TABLE *****************************************************
mysql> select * from myemployee;
+-------+---------+--------+----------+-------+---------------------+--------+-----------------+
| empno | fname   | mname  | lname    | sal   | doj                 | deptno | passportnum     |
+-------+---------+--------+----------+-------+---------------------+--------+-----------------+
|  2367 | Shubham |        | Ahire    | 50000 | 2022-01-15 00:00:00 |     50 | ASH5555835AS    |
|  2368 | Suraj   |        | Chechare | 90000 | 2022-01-25 00:00:00 |     15 | ASH555666835AS  |
|  2369 | Shubham | Ganesh | Mhaske   |  5000 | 2022-09-15 00:00:00 |     30 | ASH545835AS     |
+-------+---------+--------+----------+-------+---------------------+--------+-----------------+
3 rows in set (0.00 sec)